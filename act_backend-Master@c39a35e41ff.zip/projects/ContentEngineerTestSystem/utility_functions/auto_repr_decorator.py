# https://stackoverflow.com/questions/32910096
def auto_repr(cls):
    def __repr__(self):
        return "%s%s\n%s" % (
            "\n==============================\n",
            type(self).__name__,
            "\n".join("%s: %s" % item for item in vars(self).items()),
        )

    cls.__repr__ = __repr__
    return cls


if __name__ == "__main__":

    @auto_repr
    class TestClass:
        def __init__(self, text, text2):
            self.text = text
            self.text2 = text2

    tc = TestClass("bla", "blablubb")

    print(tc)
