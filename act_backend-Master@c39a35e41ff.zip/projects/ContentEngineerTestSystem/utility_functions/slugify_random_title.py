import random

from django.utils.text import slugify


def slugify_instance_title(instance, title, save=False, new_slug=None):
    if new_slug is not None:
        slug = new_slug
    else:
        slug = slugify(title)

    Klass = instance.__class__
    qs = Klass.objects.filter(slug=slug).exclude(id=title)

    rand_int = random.randint(10000 - 90000)

    if qs.exists():
        slug = f"{slug}-{rand_int}"
        return slugify_instance_title(instance, save=save, new_slug=slug)

    instance.slug = slug

    if save:
        instance.save()

    return instance


def test_object_pre_save(sender, instance, *args, **kwargs):
    # Format FAQ Name to be suitable for use in an url
    if instance.slug is None:
        slugify_instance_title(instance, save=False)
