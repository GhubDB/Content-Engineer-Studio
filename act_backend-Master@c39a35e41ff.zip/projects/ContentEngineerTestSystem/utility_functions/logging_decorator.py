import logging
import traceback
from asyncio.log import logger
from functools import wraps


class LoggingDecorator:
    def __init__(self) -> None:
        pass

    # https://stackoverflow.com/questions/50634303
    @staticmethod
    def log(function):
        @wraps(function)
        def wrapper(*args, **kwargs):
            try:
                result = function(*args, **kwargs)
                return result

            except Exception as e:
                logger = LoggingDecorator.make_logger()
                issue = "exception in " + function.__name__ + "\n"
                issue = issue + "=============\n"
                logger.exception(issue)
                traceback.print_exc()
                raise e

        return wrapper

    @staticmethod
    def make_logger():
        logger = logging.getLogger("exc_logger")
        logger.setLevel(logging.INFO)

        logfile = logging.FileHandler("exc_logger.log")

        fmt = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        formatter = logging.Formatter(fmt)

        logfile.setFormatter(formatter)
        logger.addHandler(logfile)
        return logger


if __name__ == "__main__":

    class DummyClass:
        @LoggingDecorator.log
        def printing(self):
            print("bla")
            raise

    dummy = DummyClass()
    dummy.printing()
