import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import { actionCreators } from "./actions/creators";

import Container from "react-bootstrap/Container";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./App.css";

import Footer from "./components/Footer";
import Header from "./components/Header";
import Database from "./screens/Database";
import Home from "./screens/Home";
import Testing from "./screens/Testing";
import Upload from "./screens/Upload";

function App() {
    const dispatch = useDispatch();
    const { getFaq } = bindActionCreators(actionCreators, dispatch);

    useEffect(() => {
        getFaq();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Router>
            <Container className=" p-2">
                <main className=" py-1">
                    <Header />
                    <Container
                        style={{ height: "82vh" }}
                        className="p-4 mb-4 bg-light rounded-3"
                    >
                        <Routes>
                            <Route path="/" element={<Home />} exact />
                            <Route path="/database" element={<Database />} />
                            <Route path="/testing/" element={<Testing />} />
                            <Route path="/import/" element={<Upload />} />
                        </Routes>
                    </Container>
                    <Footer />
                </main>
            </Container>
        </Router>
    );
}
export default App;
