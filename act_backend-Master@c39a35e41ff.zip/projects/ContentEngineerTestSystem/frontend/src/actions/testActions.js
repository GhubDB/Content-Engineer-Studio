import axios from "axios";
import {
    commands,
    CREATE_HISTORY_ITEM_FAIL,
    CREATE_HISTORY_ITEM_REQUEST,
    CREATE_HISTORY_ITEM_SUCESS,
    CREATE_TEST_FAIL,
    CREATE_TEST_REQUEST,
    CREATE_TEST_SUCESS,
    DELETE_TEST_FAIL,
    DELETE_TEST_REQUEST,
    DELETE_TEST_SUCESS,
    GET_CHAT_LOG_FAIL,
    GET_CHAT_LOG_REQUEST,
    GET_CHAT_LOG_SUCESS,
    GET_FAQ_FAIL,
    GET_FAQ_REQUEST,
    GET_FAQ_SUCESS,
    GET_HISTORY_ITEM_FAIL,
    GET_HISTORY_ITEM_REQUEST,
    GET_HISTORY_ITEM_SUCESS,
    GET_TEST_FAIL,
    GET_TEST_HISTORY_FAIL,
    GET_TEST_HISTORY_REQUEST,
    GET_TEST_HISTORY_SUCESS,
    GET_TEST_REQUEST,
    GET_TEST_SUCESS,
    IMPORT_TESTS_FAIL,
    IMPORT_TESTS_REQUEST,
    IMPORT_TESTS_SUCESS,
    PUT_HISTORY_ITEM_FAIL,
    PUT_HISTORY_ITEM_REQUEST,
    PUT_HISTORY_ITEM_SUCESS,
    PUT_TEST_FAIL,
    PUT_TEST_REQUEST,
    PUT_TEST_SUCESS,
    TEST_LIST_FAIL,
    TEST_LIST_REQUEST,
    TEST_LIST_SUCESS,
} from "../constants/testConstants";

export const listTests = () => async (dispatch) => {
    try {
        dispatch({ type: TEST_LIST_REQUEST });

        const { data } = await axios.get("/api/custom_list_test/");

        dispatch({
            type: TEST_LIST_SUCESS,
            payload: data,
        });
    } catch (error) {
        dispatch({
            type: TEST_LIST_FAIL,
            payload:
                error.response && error.response.data.message
                    ? error.response.date.message
                    : error.message,
        });
    }
};

export const getMostRecentHistoryItem =
    (command, testID = null, testData = null) =>
    async (dispatch) => {
        if (command === "GET") {
            try {
                dispatch({ type: GET_HISTORY_ITEM_REQUEST });

                const { data } = await axios
                    .get(`/api/get_most_recent_history_item/${testID}`)
                    .then((returnData) => {
                        dispatch(getChatLog(returnData.data.item_id));
                        return returnData;
                    });

                dispatch({
                    type: GET_HISTORY_ITEM_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: GET_HISTORY_ITEM_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
        if (command === "PUT") {
            try {
                dispatch({ type: PUT_HISTORY_ITEM_REQUEST });

                const { data } = await axios.put(
                    `/api/get_most_recent_history_item/${testID}`,
                    testData
                );

                dispatch({
                    type: PUT_HISTORY_ITEM_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: PUT_HISTORY_ITEM_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
        if (command === "CREATE") {
            try {
                dispatch({ type: CREATE_HISTORY_ITEM_REQUEST });

                const { data } = await axios.post(`/api/new_test/`, testData);

                dispatch({
                    type: CREATE_HISTORY_ITEM_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: CREATE_HISTORY_ITEM_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
    };

export const getTest =
    (command, testID = null, testData = null) =>
    async (dispatch) => {
        if (command === "GET") {
            try {
                dispatch({ type: GET_TEST_REQUEST });

                const { data } = await axios.get(`/api/get_test/${testID}`);

                dispatch({
                    type: GET_TEST_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: GET_TEST_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
        if (command === "PUT") {
            try {
                dispatch({ type: PUT_TEST_REQUEST });

                const { data } = await axios.put(
                    `/api/get_test/${testID}`,
                    testData
                );

                dispatch({
                    type: PUT_TEST_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: PUT_TEST_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
        if (command === "CREATE") {
            try {
                dispatch({ type: CREATE_TEST_REQUEST });

                const { data } = await axios
                    .post(`/api/new_test/`)
                    .then((returnData) => {
                        dispatch(
                            getMostRecentHistoryItem(
                                commands.GET,
                                returnData.data.test_id
                            )
                        );
                        return returnData;
                    });

                dispatch({
                    type: CREATE_TEST_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: CREATE_TEST_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
        if (command === "DELETE") {
            try {
                dispatch({ type: DELETE_TEST_REQUEST });

                const { data } = await axios.delete(`/api/get_test/${testID}`);

                dispatch({
                    type: DELETE_TEST_SUCESS,
                    payload: data,
                });
            } catch (error) {
                dispatch({
                    type: DELETE_TEST_FAIL,
                    payload:
                        error.response && error.response.data.message
                            ? error.response.date.message
                            : error.message,
                });
            }
        }
    };

export const getFaq = (id) => async (dispatch, getState) => {
    try {
        dispatch({ type: GET_FAQ_REQUEST });

        const { data } = await axios.get(`/api/list_faq/`);

        const values = data.map((opt) => ({
            label: opt["selected"],
            value: opt["id"],
        }));

        dispatch({
            type: GET_FAQ_SUCESS,
            payload: values,
        });
    } catch (error) {
        dispatch({
            type: GET_FAQ_FAIL,
            payload:
                error.response && error.response.data.message
                    ? error.response.date.message
                    : error.message,
        });
    }
};

export const getChatLog = (itemId) => async (dispatch, getState) => {
    try {
        dispatch({ type: GET_CHAT_LOG_REQUEST });

        const { data } = await axios.get(`/api/get_last_chat_log/${itemId}`);

        dispatch({
            type: GET_CHAT_LOG_SUCESS,
            payload: data,
        });
    } catch (error) {
        dispatch({
            type: GET_CHAT_LOG_FAIL,
            payload:
                error.response && error.response.data.message
                    ? error.response.date.message
                    : error.message,
        });
    }
};

export const importTests = (file, formData) => async (dispatch, getState) => {
    try {
        dispatch({ type: IMPORT_TESTS_REQUEST });

        const { data } = await axios.post(
            `/api/upload_template/`,
            file,
            formData
        );

        dispatch({
            type: IMPORT_TESTS_SUCESS,
            payload: data,
        });
    } catch (error) {
        dispatch({
            type: IMPORT_TESTS_FAIL,
            payload:
                error.response && error.response.data.message
                    ? error.response.date.message
                    : error.message,
        });
    }
};

export const getTestHistory = () => async (dispatch, getState) => {
    try {
        dispatch({ type: GET_TEST_HISTORY_REQUEST });

        const { data } = await axios.get(`/api/get_test_history/`);

        dispatch({
            type: GET_TEST_HISTORY_SUCESS,
            payload: data,
        });
    } catch (error) {
        dispatch({
            type: GET_TEST_HISTORY_FAIL,
            payload:
                error.response && error.response.data.message
                    ? error.response.date.message
                    : error.message,
        });
    }
};
