import axios from "axios";
import { useState } from "react";
import {
    Button,
    ButtonGroup,
    Card,
    Col,
    Form,
    InputGroup,
    Row,
} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { actionCreators } from "../actions/creators";
import DatabaseTable from "../components/DatabaseTable";
import Loader from "../components/Loader";
import Message from "../components/Message";

function Upload() {
    const dispatch = useDispatch();
    const { importTests } = bindActionCreators(actionCreators, dispatch);
    const importedTests = useSelector((state) => state.importTests);
    const [file, updateFile] = useState();

    console.log(importedTests?.tests);

    const handleFileChange = (e) => {
        updateFile(e.target.files[0]);
    };

    function handleUpload() {
        if (!file) return;
        const config = { headers: { "Content-Type": "multipart/form-data" } };
        let formData = new FormData();
        formData.append("file", file);
        importTests(formData, config);
    }

    function runAllTests() {
        if (!importedTests?.tests) return;
        let ids = importedTests.tests.map((obj) => {
            return obj.test_id;
        });
        console.log(ids);
        axios.post("/api/run_tests/", ids);
    }

    return (
        <>
            <div style={{ height: "72vh" }}>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Card>
                                <Card.Body>
                                    <Card.Text>
                                        <Col className="mb-3">
                                            <h4>Upload template</h4>
                                        </Col>
                                        <Col className="mb-2">
                                            <InputGroup className="mb-1">
                                                <Form.Control
                                                    type="file"
                                                    onChange={handleFileChange}
                                                    multiple
                                                />
                                                <Button
                                                    type="submit"
                                                    onClick={handleUpload}
                                                >
                                                    Upload
                                                </Button>
                                            </InputGroup>
                                        </Col>
                                    </Card.Text>
                                </Card.Body>
                            </Card>
                        </Form.Group>
                    </Col>
                    <Col>
                        <Card>
                            <Card.Body>
                                <Card.Text>
                                    <Col className="mb-3">
                                        <h4>Download template</h4>
                                    </Col>
                                    <ButtonGroup className="mb-2 d-flex">
                                        <Button variant="outline-primary">
                                            Download template
                                        </Button>{" "}
                                    </ButtonGroup>
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        {importedTests?.loading ? (
                            <Loader />
                        ) : importedTests?.error ? (
                            <Message variant="danger">
                                {importedTests.error}
                            </Message>
                        ) : importedTests ? (
                            <DatabaseTable tests={importedTests.tests} />
                        ) : (
                            <></>
                        )}
                    </Col>
                </Row>
            </div>
            <Row>
                <Col>
                    <Button onClick={runAllTests} variant="outline-primary">
                        Run all imported tests
                    </Button>{" "}
                    <Button variant="outline-primary">Run selected</Button>{" "}
                    <Button variant="outline-primary">Delete Selected</Button>
                </Col>
            </Row>
        </>
    );
}

export default Upload;
