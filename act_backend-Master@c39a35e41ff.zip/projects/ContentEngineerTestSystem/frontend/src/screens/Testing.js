import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import ChatComponent from "../components/ChatComponent";
import TestDetails from "../components/TestDetails";
import TestHistory from "../components/TestHistory";

function Testing() {
    return (
        <Container>
            <Row>
                <Col md={2}>
                    <TestHistory />
                </Col>
                <Col md={5}>
                    <ChatComponent />
                </Col>
                <Col md={5}>
                    <TestDetails />
                </Col>
            </Row>
        </Container>
    );
}

export default Testing;
