import { useEffect } from "react";
import { Button, Col, Row } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { actionCreators } from "../actions/creators";
import DatabaseTable from "../components/DatabaseTable";
import Loader from "../components/Loader";
import Message from "../components/Message";
import NewTest from "../components/NewTest";

function Database() {
    const dispatch = useDispatch();
    const { listTests } = bindActionCreators(actionCreators, dispatch);
    const testList = useSelector((state) => state.testList);
    const { error, loading, tests } = testList;

    useEffect(() => {
        listTests();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <>
            <h4>Database</h4>
            <div style={{ height: "69vh" }}>
                {loading ? (
                    <Loader />
                ) : error ? (
                    <Message variant="danger">{error}</Message>
                ) : (
                    <DatabaseTable tests={tests} />
                )}
            </div>
            <Row>
                <Col>
                    <NewTest goTesting={true} />{" "}
                    <Button
                        variant="outline-primary"
                        onClick={() => {
                            listTests();
                        }}
                    >
                        Refresh
                    </Button>{" "}
                    <Button variant="outline-primary">Run selected</Button>{" "}
                    <Button variant="outline-primary">Delete Selected</Button>
                </Col>
            </Row>
        </>
    );
}

export default Database;
