import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link } from "react-router-dom";

function Header() {
    return (
        <header>
            <Navbar bg="dark" variant="dark" expand="lg">
                <Container>
                    <Navbar.Brand as={Link} to="/">
                        ACT Home
                    </Navbar.Brand>

                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mr-auto">
                            <Nav.Link as={Link} to="/testing">
                                <i className="fas fa-flask-vial"></i>Testing
                            </Nav.Link>
                            <Nav.Link as={Link} to="/database">
                                <i className="fas fa-database"></i> Database
                            </Nav.Link>
                            <Nav.Link as={Link} to="/my-tests">
                                <i className="fas fa-person"></i> My Tests
                            </Nav.Link>
                            <Nav.Link as={Link} to="/import">
                                <i className="fas fa-file-import"></i> Import
                            </Nav.Link>
                            <Nav.Link as={Link} to="#">
                                <i className="fas fa-file-export"></i> Export
                            </Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </header>
    );
}

export default Header;
