import { useEffect, useRef, useState } from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import ListGroup from "react-bootstrap/ListGroup";
import Row from "react-bootstrap/Row";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Select from "react-select";
import makeAnimated from "react-select/animated";
import { bindActionCreators } from "redux";
import { actionCreators } from "../actions/creators";
import { commands } from "../constants/testConstants";
import Loader from "./Loader";
import Message from "./Message";
import NewTest from "./NewTest";

function TestDetails() {
    const inputCase = {
        ITEM: "ITEM",
        TEST: "TEST",
    };

    const animatedComponents = makeAnimated();

    const dispatch = useDispatch();
    const { getTest, getMostRecentHistoryItem } = bindActionCreators(
        actionCreators,
        dispatch
    );

    const currentTest = useSelector((state) => state.currentTest);
    const historyItem = useSelector((state) => state.historyItem);
    const faqList = useSelector((state) => state.faqList);

    const [currentTestState, setTestState] = useState(null);
    const [currentItemState, setItemState] = useState(null);
    const stateGetter = {
        TEST: currentTestState,
        ITEM: currentItemState,
    };
    const stateSetter = {
        TEST: setTestState,
        ITEM: setItemState,
    };
    const navigate = useNavigate();

    function isLoading() {
        if (currentTest.loading || historyItem.loading || faqList.loading) {
            return true;
        }
        return false;
    }

    function isNull() {
        if (!(currentTest.test && historyItem.item && faqList.faqs)) {
            return true;
        }
        return false;
    }

    const prevTestState = useRef();
    const prevItemState = useRef();
    useEffect(() => {
        if (isNull() || isLoading()) {
            return;
        }
        // Update state if the values in the Redux store have changed.
        if (currentTest.test !== prevTestState.current) {
            handleStateChange(null, null, inputCase.TEST, currentTest.test);
        }
        if (historyItem.item !== prevItemState.current) {
            handleStateChange(null, null, inputCase.ITEM, historyItem.item);
        }

        prevTestState.current = currentTest.test;
        prevItemState.current = historyItem.item;
    });

    function handleStateChange(
        key = null,
        opt = null,
        inputCase = null,
        update = null
    ) {
        const setState = stateSetter[inputCase];
        setState((prevState) => {
            if (update != null) {
                return update;
            }

            if (prevState == null) {
                return prevState;
            }

            // Check if the object is nested
            // https://stackoverflow.com/questions/57798841
            prevState[key] = { id: opt.value, selected: opt.label };
            console.log(prevState[key]);

            return { ...prevState };
        });
    }

    function makeDropdown(key, inputCase) {
        let opts = mapArrayToLabelAndValue(key, inputCase);
        // console.log(stateGetter[inputCase][key]?.selected);

        return (
            <>
                <label>{key}</label>
                <Select
                    options={opts.options}
                    name={key}
                    value={
                        stateGetter[inputCase] == null ||
                        stateGetter[inputCase][key] == null
                            ? null
                            : {
                                  label: stateGetter[inputCase][key].selected,
                                  value: stateGetter[inputCase][key].id - 1,
                              }
                    }
                    components={animatedComponents}
                    onChange={(opt) => handleStateChange(key, opt, inputCase)}
                />
            </>
        );
    }

    function mapArrayToLabelAndValue(key, inputCase) {
        let opts = {};

        if (key.includes("faq")) {
            opts["options"] = faqList.faqs;
            if (inputCase === "TEST") {
                opts["id"] = currentTest.test[key]?.id;
                opts["selected"] = currentTest.test[key]?.selected;
            }
            if (inputCase === "ITEM") {
                opts["id"] = historyItem.item[key]?.id;
                opts["selected"] = historyItem.item[key]?.selected;
            }
        } else if (inputCase === "TEST") {
            opts = currentTest.test[key];
        } else if (inputCase === "ITEM") {
            opts = historyItem.item[key];
        }
        // opts["value"] = { label: opts.selected, value: opts.id };

        return opts;
    }

    const onSubmit = async (e) => {
        e.preventDefault();

        // Handle 'Comment' input field
        setItemState((prevState) => {
            prevState["comment"] = e.target.comment.value;
            return prevState;
        });

        let testID = currentTestState["test_id"];
        getTest(commands.PUT, testID, currentTestState);
        getMostRecentHistoryItem(commands.PUT, testID, currentItemState);
    };

    return (
        <>
            {isLoading() ? (
                <Loader />
            ) : isNull() ? (
                <NewTest />
            ) : currentTest.error || historyItem.error || faqList.error ? (
                <Message variant="danger">
                    {(currentTest.error, historyItem.error)}
                </Message>
            ) : (
                <form onSubmit={onSubmit}>
                    <Row>
                        <Row>
                            <Col>
                                <ListGroup className="my-1 rounded">
                                    <ListGroup.Item>
                                        <strong>TestID: </strong>
                                        {currentTestState &&
                                            currentTestState.test_id}
                                    </ListGroup.Item>
                                    <ListGroup.Item>
                                        <Row>
                                            <Col>
                                                <strong>Rating: </strong>{" "}
                                                <Button
                                                    variant="outline-primary"
                                                    size="sm"
                                                    className="mr-1"
                                                >
                                                    <i className="fas fa-thumbs-up" />
                                                </Button>{" "}
                                                <Button
                                                    size="sm"
                                                    variant="outline-primary"
                                                >
                                                    <i className="fas fa-thumbs-down" />
                                                </Button>
                                            </Col>
                                        </Row>
                                    </ListGroup.Item>
                                </ListGroup>
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <Row className="my-1">
                                    {makeDropdown("language", inputCase.TEST)}
                                </Row>
                                <Row className="my-1">
                                    {makeDropdown("topic", inputCase.TEST)}
                                </Row>
                                <Row className="my-1">
                                    {makeDropdown(
                                        "test_status",
                                        inputCase.ITEM
                                    )}
                                </Row>
                            </Col>
                            <Col>
                                <Row className="my-1">
                                    {makeDropdown(
                                        "test_quality",
                                        inputCase.ITEM
                                    )}
                                </Row>
                                <Row className="my-1">
                                    {makeDropdown(
                                        "implementation_status",
                                        inputCase.TEST
                                    )}
                                </Row>
                                <Row className="my-1">
                                    {makeDropdown("priority", inputCase.TEST)}
                                </Row>
                            </Col>
                        </Row>
                    </Row>
                    <Row>
                        <Row className="my-1">
                            {makeDropdown("correct_faq", inputCase.TEST)}
                        </Row>
                        <Row className="my-1">
                            {makeDropdown("actual_faq", inputCase.ITEM)}
                        </Row>
                    </Row>
                    <Row>
                        <Col>
                            <Form.Group className="mb-1">
                                <Form.Label>Comment</Form.Label>
                                <Form.Control
                                    defaultValue={
                                        currentItemState?.comment == null
                                            ? ""
                                            : currentItemState.comment
                                    }
                                    name="comment"
                                    as="textarea"
                                    rows={8}
                                />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Button
                                className="my-1"
                                type="submit"
                                variant="outline-primary"
                            >
                                Save
                            </Button>{" "}
                            <Button className="my-1" variant="outline-primary">
                                Clone Test
                            </Button>{" "}
                            <Button className="my-1" variant="outline-primary">
                                Run Test
                            </Button>{" "}
                            <NewTest className="my-1" />{" "}
                            <Button
                                className="my-1"
                                variant="outline-primary"
                                onClick={() => {
                                    getTest(
                                        commands.DELETE,
                                        currentTestState["test_id"]
                                    ).then(navigate("../Database"));
                                }}
                            >
                                Delete Test
                            </Button>{" "}
                        </Col>
                    </Row>
                </form>
            )}
        </>
    );
}

export default TestDetails;
