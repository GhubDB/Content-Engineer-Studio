import { Container, Row } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import Table from "react-bootstrap/Table";
import { Link } from "react-router-dom";

import { useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import { actionCreators } from "../actions/creators";
import { commands } from "../constants/testConstants";

function DatabaseTable({ tests }) {
    const dispatch = useDispatch();
    const { getMostRecentHistoryItem, getTest } = bindActionCreators(
        actionCreators,
        dispatch
    );
    return (
        <>
            <Container>
                <Row>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>
                                    {" "}
                                    <Form.Group controlId="formBasicCheckbox">
                                        <Form.Check type="checkbox" />
                                    </Form.Group>
                                </th>
                                <th>ID</th>
                                <th>Correct FAQ</th>
                                <th>Updated</th>
                                <th>First Message</th>
                                <th>Topic</th>
                                <th>Lang</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tests.map((item) => (
                                <tr key={item.test_id}>
                                    <td>
                                        {" "}
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" />
                                        </Form.Group>
                                    </td>
                                    <td>
                                        <Link
                                            to={`/testing/`}
                                            // https://ui.dev/react-router-pass-props-to-link
                                            onClick={() => {
                                                getMostRecentHistoryItem(
                                                    commands.GET,
                                                    item.test_id
                                                );
                                                getTest(
                                                    commands.GET,
                                                    item.test_id
                                                );
                                            }}
                                        >
                                            {item.test_id.slice(0, 8)}
                                        </Link>
                                    </td>
                                    <td>{item.correct_faq_name}</td>
                                    <td>{item.updated_timestamp}</td>
                                    <td>{item.get_first_question}</td>
                                    <td>{item.topic_name}</td>
                                    <td>{item.language_name}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Row>
            </Container>
        </>
    );
}

export default DatabaseTable;
