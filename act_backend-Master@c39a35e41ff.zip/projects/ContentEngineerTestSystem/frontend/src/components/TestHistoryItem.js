import { ListGroup, ListGroupItem } from "react-bootstrap";

function TestHistoryItem({ index, history }) {
    // <ListGroup.Item>{faq}</ListGroup.Item>
    // <ListGroup.Item>{first_message}</ListGroup.Item>
    // <ListGroupItem>{timestamp}</ListGroupItem>
    return (
        <>
            <ListGroup key={index} variant="flush" className="my-3 rounded">
                <ListGroupItem>
                    <strong>{history.correct_faq_name}</strong> <br />{" "}
                    {history.get_first_question} <br />{" "}
                    {history.updated_timestamp}
                </ListGroupItem>
            </ListGroup>
        </>
    );
}

export default TestHistoryItem;
