import { Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { bindActionCreators } from "redux";
import { actionCreators } from "../actions/creators";
import { commands } from "../constants/testConstants";
function NewTest({ goTesting }) {
    const dispatch = useDispatch();
    const { getTest } = bindActionCreators(actionCreators, dispatch);
    const navigate = useNavigate();

    return (
        <>
            <Button
                variant="outline-primary"
                onClick={() => {
                    getTest(commands.CREATE);
                    if (goTesting) {
                        navigate("../Testing", { replace: true });
                    }
                }}
            >
                New Test
            </Button>
        </>
    );
}

export default NewTest;
