import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { actionCreators } from "../actions/creators";
import Loader from "./Loader";
import Message from "./Message";
import "./NoScrollbar.css";
import TestHistoryItem from "./TestHistoryItem";

function TestHistory() {
    const dispatch = useDispatch();
    const { getTestHistory } = bindActionCreators(actionCreators, dispatch);
    const testHistory = useSelector((state) => state.getTestHistory);

    useEffect(() => {
        getTestHistory();
        console.log(testHistory);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <>
            {testHistory?.loading ? (
                <Loader />
            ) : testHistory?.error ? (
                <Message variant="danger">{testHistory.error}</Message>
            ) : (
                <div
                    style={{
                        height: `77vh`,
                        overflow: "hidden",
                    }}
                >
                    {testHistory?.history &&
                        testHistory.history.map((item, index) => {
                            return (
                                <TestHistoryItem key={index} history={item} />
                            );
                        })}
                </div>
            )}
        </>
    );
}

export default TestHistory;
