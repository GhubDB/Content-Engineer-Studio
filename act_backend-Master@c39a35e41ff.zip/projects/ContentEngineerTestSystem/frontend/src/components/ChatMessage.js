import Card from "react-bootstrap/Card";

function ChatMessage({ message }) {
    return (
        <Card
            // bg={"light"}
            style={{
                backgroundColor:
                    message.participant === "Bot" ? "#C3C2FF" : "gainsboro",
            }}
            className={" my-1 rounded-3"}
        >
            <Card.Body>
                <Card.Text>
                    <strong> {message.participant + ":  "} </strong>
                    {message.message}
                </Card.Text>
            </Card.Body>
        </Card>
    );
}

export default ChatMessage;
