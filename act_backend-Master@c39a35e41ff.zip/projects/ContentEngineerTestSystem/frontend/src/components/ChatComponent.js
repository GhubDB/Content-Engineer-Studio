import { useEffect, useRef, useState } from "react";
import {
    Alert,
    Button,
    Col,
    FormControl,
    InputGroup,
    Row,
} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { w3cwebsocket as W3CWebSocket } from "websocket";
import { actionCreators } from "../actions/creators";
import "./ChatAlert.css";
import ChatMessage from "./ChatMessage";
import Loader from "./Loader";

function ChatComponent() {
    const dispatch = useDispatch();
    const { getChatLog } = bindActionCreators(actionCreators, dispatch);
    const currentTest = useSelector((state) => state.currentTest);
    const historyItem = useSelector((state) => state.historyItem);
    const faqList = useSelector((state) => state.faqList);
    const chatLog = useSelector((state) => state.chatLog);

    const chatSocket = useRef(null);
    const alertContainerRef = useRef();
    const dummy = useRef();

    // TODO: add mode selection
    // const [mode, setMode] = useState("WHATSAPP");
    const [messageState, setMessageState] = useState("");
    const [liveChatLog, setLiveChatLog] = useState([]);
    const [connectionStatus, setConnectionStatus] = useState();
    const [alerts, setAlerts] = useState(null);
    const [isShowingAlert, setShowingAlert] = useState(false);
    const roomName = historyItem.item?.item_id;

    useEffect(() => {
        // Update chatSocket ready state
        if (
            chatSocket.current == null ||
            typeof chatSocket.current?.readyState == "undefined"
        ) {
            return;
        }
        setConnectionStatus((prevState) => {
            if (prevState !== chatSocket.current.readyState) {
                return chatSocket.current.readyState;
            }
        });
    }, []);

    function isLoading() {
        if (
            currentTest.loading ||
            historyItem.loading ||
            faqList.loading ||
            chatLog?.loading
        ) {
            return true;
        }
        return false;
    }

    function isNull() {
        if (!(currentTest.test && historyItem.item && faqList.faqs)) {
            return true;
        }
        return false;
    }

    const handleTextInputChange = (e) => {
        setMessageState(e.target.value);
    };

    // clear the 'chatMessageInput' and forward the message
    const onSubmit = (e) => {
        e.preventDefault();

        if (messageState === "" || chatSocket.current == null) return;
        chatSocket.current.send(
            JSON.stringify({
                type: "chat_message",
                message: messageState,
            })
        );
        setMessageState("");
    };

    function connect() {
        console.log("Connecting...");
        if (!chatSocket.current) {
            chatSocket.current = new W3CWebSocket(
                "ws://127.0.0.1:8000/ws/chat/" + roomName + "/"
                // "ws://" + window.location.host + "/ws/chat/" + roomName + "/"
            );
        }

        chatSocket.current.onopen = function (e) {
            console.log("Successfully connected to the WebSocket.");
            setConnectionStatus(chatSocket.current.readyState);
        };

        chatSocket.current.onclose = function (e) {
            cleanUpWebSocket();
            //     console.log(roomName);
            //     console.log(
            //         "WebSocket connection closed unexpectedly. Trying to reconnect in 2s..."
            //     );
            //     setTimeout(function () {
            //         console.log("Reconnecting...");
            //         connect();
            //     }, 2000);
        };

        chatSocket.current.onmessage = function (e) {
            const messageData = JSON.parse(e.data);
            if (typeof messageData == "undefined") return;

            switch (messageData.type) {
                case "chat_message":
                    setLiveChatLog((prevState) => {
                        prevState.push(messageData);
                        return [...prevState];
                    });
                    break;

                case "system_message":
                    setAlerts(messageData);
                    setShowingAlert(true);
                    console.log(messageData.message);
                    break;

                case "command":
                    commandProcessor(messageData);
                    console.log(messageData.message);
                    break;

                default:
                    console.error("Unknown message type!");
                    break;
            }
        };
        chatSocket.current.onerror = function (err) {
            console.log(err);
            // console.log("WebSocket encountered an error: " + err.message);
            console.log("Closing the socket.");
            cleanUpWebSocket();
        };
    }

    function end_session() {
        console.log("Closing websocket connection");
        chatSocket.current.send(
            JSON.stringify({
                type: "command",
                payload: "end_session",
            })
        );
    }

    function commandProcessor(command) {
        if (command.payload === "get_chat_log") {
            getChatLog(historyItem.item.item_id);
            setLiveChatLog(null);
        }
        cleanUpWebSocket();
    }

    function cleanUpWebSocket() {
        chatSocket.current.close();
        setConnectionStatus(chatSocket.current.readyState);
        chatSocket.current = null;
    }

    function isReady() {
        if (connectionStatus === WebSocket.CONNECTING) {
            return (
                <Button
                    name="connecting"
                    variant="outline-info"
                    onClick={connect}
                >
                    Connecting
                </Button>
            );
        }
        if (connectionStatus === WebSocket.OPEN) {
            return <></>;
        }
        return (
            <Button name="connect" variant="outline-success" onClick={connect}>
                Connect
            </Button>
        );
    }

    function shouldShowDisconnect() {
        if (connectionStatus === WebSocket.OPEN) {
            return (
                <Button
                    name="end-session"
                    variant="outline-danger"
                    onClick={end_session}
                >
                    End session
                </Button>
            );
        }
    }

    function makeStaticChatLog() {
        return chatLog.chatLog.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
        ));
    }

    function existChatLog() {
        if (chatLog?.chatLog.length === 0) return false;
        return true;
    }

    function makeLiveChatLog() {
        try {
            return liveChatLog.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
            ));
        } finally {
            // Scroll down chat-log
            dummy.current?.scrollIntoView({ behavior: "smooth" });
        }
    }

    function ChatAlert() {
        // https://stackoverflow.com/questions/42733986
        if (isShowingAlert) {
            return (
                <Alert
                    ref={alertContainerRef}
                    variant={alerts.style}
                    className={` ${
                        isShowingAlert ? "alert-shown" : "alert-hidden"
                    }`}
                    onTransitionEnd={() => setShowingAlert(false)}
                    // onClose={() => setShowingAlert(false)}
                    // dismissible
                    // style={{
                    //     height: "6vh",
                    // }}
                >
                    {alerts.message}
                </Alert>
            );
        }
    }

    return (
        <div>
            {isLoading() ? (
                <Loader />
            ) : isNull() ? (
                <></>
            ) : existChatLog() ? (
                <>
                    <div
                        style={{
                            height: `70vh`,
                            overflow: "auto",
                        }}
                        className="my-1"
                    >
                        {makeStaticChatLog()}
                    </div>
                    <Row>
                        <Col>
                            <Button
                                name="chatMessageSend"
                                variant="outline-primary"
                                type="submit"
                            >
                                Start new session
                            </Button>{" "}
                            <Button
                                name="chatMessageSend"
                                variant="outline-primary"
                                type="submit"
                            >
                                Save updated chat log
                            </Button>
                        </Col>
                    </Row>
                </>
            ) : (
                <>
                    <div
                        style={{
                            height: `${isShowingAlert ? 62 : 70}vh`,
                            overflow: "auto",
                        }}
                        className="my-1"
                    >
                        {liveChatLog && makeLiveChatLog()}
                        <div ref={dummy}></div>
                    </div>
                    {alerts && ChatAlert()}
                    <form onSubmit={onSubmit}>
                        <InputGroup className="mb-1">
                            <FormControl
                                placeholder="Send"
                                name="message"
                                onChange={handleTextInputChange}
                                value={messageState}
                            />
                            <Button
                                name="chatMessageSend"
                                variant="outline-primary"
                                type="submit"
                            >
                                Send
                            </Button>
                            {isReady()}
                            {shouldShowDisconnect()}
                        </InputGroup>
                    </form>
                </>
            )}
        </div>
    );
}

export default ChatComponent;
