import { combineReducers } from "redux";
import {
    chatLogReducer,
    faqReducer,
    getMostRecentHistoryItemReducer,
    getTestHistoryReducer,
    getTestReducer,
    importTestReducer,
    testListReducer,
} from "./testReducers";

const reducers = combineReducers({
    testList: testListReducer,
    currentTest: getTestReducer,
    historyItem: getMostRecentHistoryItemReducer,
    faqList: faqReducer,
    chatLog: chatLogReducer,
    importTests: importTestReducer,
    getTestHistory: getTestHistoryReducer,
});

export default reducers;
