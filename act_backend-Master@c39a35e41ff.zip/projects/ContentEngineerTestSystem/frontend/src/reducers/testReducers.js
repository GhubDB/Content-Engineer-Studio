import {
    CREATE_HISTORY_ITEM_FAIL,
    CREATE_HISTORY_ITEM_REQUEST,
    CREATE_HISTORY_ITEM_SUCESS,
    CREATE_TEST_FAIL,
    CREATE_TEST_REQUEST,
    CREATE_TEST_SUCESS,
    DELETE_TEST_FAIL,
    DELETE_TEST_REQUEST,
    DELETE_TEST_SUCESS,
    GET_CHAT_LOG_FAIL,
    GET_CHAT_LOG_REQUEST,
    GET_CHAT_LOG_SUCESS,
    GET_FAQ_FAIL,
    GET_FAQ_REQUEST,
    GET_FAQ_SUCESS,
    GET_HISTORY_ITEM_FAIL,
    GET_HISTORY_ITEM_REQUEST,
    GET_HISTORY_ITEM_SUCESS,
    GET_TEST_FAIL,
    GET_TEST_HISTORY_FAIL,
    GET_TEST_HISTORY_REQUEST,
    GET_TEST_HISTORY_SUCESS,
    GET_TEST_REQUEST,
    GET_TEST_SUCESS,
    IMPORT_TESTS_FAIL,
    IMPORT_TESTS_REQUEST,
    IMPORT_TESTS_SUCESS,
    PUT_HISTORY_ITEM_FAIL,
    PUT_HISTORY_ITEM_REQUEST,
    PUT_HISTORY_ITEM_SUCESS,
    PUT_TEST_FAIL,
    PUT_TEST_REQUEST,
    PUT_TEST_SUCESS,
    TEST_LIST_FAIL,
    TEST_LIST_REQUEST,
    TEST_LIST_SUCESS,
} from "../constants/testConstants";

export const testListReducer = (state = { tests: [] }, action) => {
    switch (action.type) {
        case TEST_LIST_REQUEST:
            return { loading: true, tests: [] };

        case TEST_LIST_SUCESS:
            return { loading: false, tests: action.payload };

        case TEST_LIST_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};

export const getTestReducer = (state = { test: null }, action) => {
    switch (action.type) {
        case GET_TEST_REQUEST:
            return { loading: true, ...state };

        case GET_TEST_SUCESS:
            return { loading: false, test: action.payload };

        case GET_TEST_FAIL:
            return { loading: false, error: action.payload };

        case PUT_TEST_REQUEST:
            return { loading: true, ...state };

        case PUT_TEST_SUCESS:
            return { loading: false, test: action.payload };

        case PUT_TEST_FAIL:
            return { loading: false, error: action.payload };

        case CREATE_TEST_REQUEST:
            return { loading: true, ...state };

        case CREATE_TEST_SUCESS:
            return { loading: false, test: action.payload };

        case CREATE_TEST_FAIL:
            return { loading: false, error: action.payload };

        case DELETE_TEST_REQUEST:
            return { loading: true, ...state };

        case DELETE_TEST_SUCESS:
            return { loading: false, test: null };

        case DELETE_TEST_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};

export const getMostRecentHistoryItemReducer = (
    state = { historyItem: null },
    action
) => {
    switch (action.type) {
        case GET_HISTORY_ITEM_REQUEST:
            return { loading: true, ...state };

        case GET_HISTORY_ITEM_SUCESS:
            return { loading: false, item: action.payload };

        case GET_HISTORY_ITEM_FAIL:
            return { loading: false, error: action.payload };

        case PUT_HISTORY_ITEM_REQUEST:
            return { loading: true, ...state };

        case PUT_HISTORY_ITEM_SUCESS:
            return { loading: false, item: action.payload };

        case PUT_HISTORY_ITEM_FAIL:
            return { loading: false, error: action.payload };

        case CREATE_HISTORY_ITEM_REQUEST:
            return { loading: true, ...state };

        case CREATE_HISTORY_ITEM_SUCESS:
            return { loading: false, item: action.payload };

        case CREATE_HISTORY_ITEM_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};

export const faqReducer = (state = { faq: {} }, action) => {
    switch (action.type) {
        case GET_FAQ_REQUEST:
            return { loading: true, ...state };

        case GET_FAQ_SUCESS:
            return { loading: false, faqs: action.payload };

        case GET_FAQ_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};

export const chatLogReducer = (state = null, action) => {
    switch (action.type) {
        case GET_CHAT_LOG_REQUEST:
            return { loading: true, ...state };

        case GET_CHAT_LOG_SUCESS:
            return { loading: false, chatLog: action.payload };

        case GET_CHAT_LOG_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};

export const importTestReducer = (state = null, action) => {
    switch (action.type) {
        case IMPORT_TESTS_REQUEST:
            return { loading: true, ...state };

        case IMPORT_TESTS_SUCESS:
            return { loading: false, tests: action.payload };

        case IMPORT_TESTS_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};

export const getTestHistoryReducer = (state = { history: null }, action) => {
    switch (action.type) {
        case GET_TEST_HISTORY_REQUEST:
            return { loading: true, ...state };

        case GET_TEST_HISTORY_SUCESS:
            return { loading: false, history: action.payload };

        case GET_TEST_HISTORY_FAIL:
            return { loading: false, error: action.payload };

        default:
            return state;
    }
};
