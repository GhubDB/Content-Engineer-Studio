from database import models, services
from django.urls import reverse
from drf_writable_nested.serializers import WritableNestedModelSerializer
from rest_framework import generics, parsers, serializers
from rest_framework.exceptions import NotFound
from rest_framework.response import Response
from rest_framework.views import APIView
from test_runner import threadpool_manager

from api import api_serializers


class GetTest(generics.RetrieveUpdateDestroyAPIView):
    queryset = models.TestObject.objects.all()
    serializer_class = api_serializers.GetTestSerializer
    lookup_field = "test_id"


# https://stackoverflow.com/questions/62024414/
# https://www.cdrf.co/3.13/rest_framework.generics/RetrieveUpdateDestroyAPIView.html
class GetMostRecentHistoryItem(generics.RetrieveUpdateDestroyAPIView):

    queryset = models.TestHistoryItem.objects.all()
    serializer_class = api_serializers.HistoryItemSerializer

    def get_object(self):
        test = models.TestObject.objects.filter(test_id=self.kwargs["test_id"])
        if not test:
            raise NotFound(detail="Error 404, test not found", code=404)

        item = test[0].get_most_recent_history_item()
        if not item:
            raise NotFound(
                detail="Error 404, no previous result found for this test", code=404
            )

        return item


# YT - Django structure for scale and longevity
class LastChatLog(APIView):
    class ChatLogSerializer(serializers.ModelSerializer):
        participant = serializers.CharField(source="participant.options")

        class Meta:
            model = models.ChatLogItem
            fields = "__all__"

    def get(self, request, item_id: str):
        messages = services.get_most_recent_chat_log(item_id=item_id)
        serializer = self.ChatLogSerializer(messages, many=True)
        return Response(serializer.data)


class ListFaq(generics.ListAPIView):
    # https://www.django-rest-framework.org/api-guide/views/
    # https://www.youtube.com/watch?v=yG3ZdxBb1oo
    # .get(), .post(), put(), patch() and .delete()

    queryset = models.Faq.objects.all()
    serializer_class = api_serializers.FAQSerializer


class CreateTestObject(generics.CreateAPIView):
    serializer_class = api_serializers.GetTestSerializer

    def perform_create(self, serializer):
        obj = serializer.save()
        models.TestHistoryItem.objects.create(test=obj, is_live=True)


class CloneHistoryItem(generics.CreateAPIView):
    """TODO: finish implementing this"""

    class CloneHistoryItemSerializer:
        class Meta:
            model = models.TestHistoryItem
            fields = "__all__"

    serializer_class = CloneHistoryItemSerializer
    queryset = models.TestHistoryItem.objects.all()

    def perform_create(self, serializer):
        if not self.queryset:
            raise NotFound(detail="Error 404, item not found", code=404)

        # Clone item
        obj = self.queryset
        obj["pk"], obj["is_live"] = None, True
        obj.save()

        # Clone questions
        questions = models.Questions.objects.filter(history_item=obj).order_by("number")
        if questions:
            for question in questions:
                question["pk"] = None
                question.save()

        serializer = self.CloneHistoryItemSerializer(obj)
        return Response(serializer.data)

    def get_queryset(self, request, item_id: str):
        return models.TestHistoryItem.objects.filter(item_id=item_id).first()


class CustomListTestObjects(generics.ListAPIView):
    queryset = models.TestObject.objects.all()
    serializer_class = api_serializers.CustomListTestSerializer


class ListTestObjects(generics.ListAPIView):
    class ListTestSerializer(serializers.ModelSerializer):
        class Meta:
            model = models.TestObject
            fields = "__all__"

    queryset = models.TestObject.objects.all()
    serializer_class = ListTestSerializer


class ListCreateTestObjects(generics.ListCreateAPIView):
    class ListCreateTestSerializer(serializers.ModelSerializer):
        class Meta:
            model = models.TestObject
            fields = "__all__"

    queryset = models.TestObject.objects.all()
    serializer_class = ListCreateTestSerializer

    def get_url(self, obj):
        request = self.context.get("request")
        if request is None:
            return None

        return reverse("", kwargs={"pk": obj.pk}, request=request)

    # Show only tests created by the user that made the request.
    # def get_queryset(self):
    #     return models.TestObject.objects.filter(created_userid=self.request.user)


class FileUploadView(APIView):
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def post(self, request, format=None):
        file_obj = request.data["file"]
        uploaded_tests = services.process_template(template_file=file_obj)
        print("Added " + str(len(uploaded_tests)) + " tests.")
        serializer = api_serializers.CustomListTestSerializer(uploaded_tests, many=True)
        return Response(serializer.data, status=200)


class RunTests(APIView):
    def post(self, request, format=None):
        history_items = [
            obj.get_most_recent_history_item()
            for obj in self.get_queryset(request.data)
        ]
        threadpool_manager.thread_pool_manager.feed_queue(history_items)
        print("Running " + str(len(history_items)) + "tests.")
        return Response(status=204)

    def get_queryset(self, ids):
        return models.TestObject.objects.filter(test_id__in=ids)


class TestHistory(generics.ListAPIView):
    class TestHistorySerializer(serializers.ModelSerializer):
        correct_faq_name = serializers.CharField(
            source="correct_faq.options", required=False
        )
        get_first_question = serializers.CharField(required=False)

        class Meta:
            model = models.TestObject
            fields = (
                "correct_faq_name",
                "get_first_question",
                "updated_timestamp",
            )

    queryset = models.TestObject.objects.all()
    serializer_class = TestHistorySerializer

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        queryset = queryset.order_by("-updated_timestamp")

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
