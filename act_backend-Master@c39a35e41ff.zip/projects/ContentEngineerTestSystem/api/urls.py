from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token

from . import views

app_name = "api"

urlpatterns = [
    # path("live_items/", views.ListLiveHistoryItems.as_view(), name="live_items"),
    path(
        "get_most_recent_history_item/<str:test_id>",
        views.GetMostRecentHistoryItem.as_view(),
        name="get_most_recent_history_item",
    ),
    path("get_test/<str:test_id>", views.GetTest.as_view(), name="get_test"),
    path("new_test/", views.CreateTestObject.as_view(), name="new_test"),
    path("list_test/", views.ListTestObjects.as_view(), name="list_test"),
    path(
        "custom_list_test/",
        views.CustomListTestObjects.as_view(),
        name="custom_list_test",
    ),
    path("list_new_test/", views.ListCreateTestObjects.as_view(), name="list_new_test"),
    path(
        "get_last_chat_log/<str:item_id>/",
        views.LastChatLog.as_view(),
        name="get_last_chat_log",
    ),
    path("list_faq/", views.ListFaq.as_view(), name="list_faq"),
    path("auth/", obtain_auth_token),
    path("upload_template/", views.FileUploadView.as_view(), name="upload_template"),
    path("run_tests/", views.RunTests.as_view(), name="run_tests"),
    path("get_test_history/", views.TestHistory.as_view(), name="get_test_history"),
]
