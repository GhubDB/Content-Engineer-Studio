from doctest import testmod

from database import models
from drf_writable_nested.serializers import WritableNestedModelSerializer
from rest_framework import generics, serializers


class MultiChoiceSerializer(serializers.ModelSerializer):
    """This base class adds the available options as an additonal field."""

    options = serializers.SerializerMethodField(required=False)
    selected = serializers.CharField(source="options", required=False)

    class Meta:
        fields = "__all__"

    def get_options(self, obj):
        return [
            {"label": obj.options, "value": obj.pk}
            for obj in self.Meta.model.objects.all()
        ]


class QualitySerializer(MultiChoiceSerializer):
    class Meta:
        model = models.QualityModel
        fields = "__all__"


class TestModesModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.TestModesModel
        fields = "__all__"


class LanguagesModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.LanguagesModel
        fields = "__all__"


class PriorityModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.PriorityModel
        fields = "__all__"


class TestResultModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.TestResultModel
        fields = "__all__"


class ImplementationStatusModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.ImplementationStatusModel
        fields = "__all__"


class TopicModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.TopicModel
        fields = "__all__"


class ParticipantModelSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.ParticipantModel
        fields = "__all__"


class TestGroupSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.TestGroup
        fields = "__all__"


class VariantSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.Variant
        fields = "__all__"


class QuestionsSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.Questions
        fields = "__all__"


class FAQSerializer(WritableNestedModelSerializer):
    selected = serializers.CharField(source="options", required=False)

    class Meta:
        model = models.Faq
        fields = ("id", "selected")


class ChatLogItemSerializer(MultiChoiceSerializer):
    class Meta:
        model = models.ChatLogItem
        fields = "__all__"


class CustomListTestSerializer(serializers.ModelSerializer):
    correct_faq_name = serializers.CharField(
        source="correct_faq.options", required=False
    )
    topic_name = serializers.CharField(source="topic.options")
    language_name = serializers.CharField(source="language.options")
    get_first_question = serializers.CharField(required=False)

    class Meta:
        model = models.TestObject
        fields = (
            "test_id",
            "correct_faq_name",
            "topic_name",
            "get_first_question",
            "language_name",
            "updated_timestamp",
        )


class GetTestSerializer(WritableNestedModelSerializer):
    topic = TopicModelSerializer(required=False)
    language = LanguagesModelSerializer(required=False)
    implementation_status = ImplementationStatusModelSerializer(required=False)
    priority = PriorityModelSerializer(required=False)
    correct_faq = FAQSerializer(required=False, allow_null=True)

    class Meta:
        model = models.TestObject
        fields = "__all__"
        lookup_field = "test_id"


class HistoryItemSerializer(WritableNestedModelSerializer):
    test_quality = QualitySerializer()
    test_status = TestResultModelSerializer()
    actual_faq = FAQSerializer(required=False, allow_null=True)

    class Meta:
        model = models.TestHistoryItem
        fields = "__all__"
