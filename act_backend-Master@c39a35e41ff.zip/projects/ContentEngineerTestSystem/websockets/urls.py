from django.urls import path

from websockets import views

# YT Build an Asynchronous Chatroom with Django and Channels

urlpatterns = [
    path("<str:room_name>/", views.live_test, name="live_test"),
]
