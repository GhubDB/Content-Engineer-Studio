from django.urls import re_path

from websockets import consumers

websocket_urlpatterns = [
    # Catch incoming traffic to SERVERURL/chat/TestHistoryItem_id
    # \w+ matches characters
    # /$ makes sure everything after / is not matched:
    # SERVERURL/chat/TestHistoryItem_id/EXAMPLE -> no match
    # re_path(r"ws/chat/(?P<room_name>\w+)/$", consumers.ChatConsumer.as_asgi()),
    # https://stackoverflow.com/questions/54107099/django-channels-no-route-found-for-path
    re_path(r"^ws/chat/(?P<room_name>[^/]+)/$", consumers.ChatConsumer.as_asgi()),
]
