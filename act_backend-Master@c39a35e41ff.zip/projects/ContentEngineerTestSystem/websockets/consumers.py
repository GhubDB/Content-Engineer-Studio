import json
import queue
import uuid

from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer
from database import models
from test_runner.threadpool_manager import thread_pool_manager


class ChatConsumer(WebsocketConsumer):
    """https://testdriven.io/blog/django-channels/"""

    def __init__(self, *args, **kwargs):
        super().__init__(args, kwargs)
        self.room_name = None
        self.room_group_name = None
        self.history_item = None
        self.chat_log = None
        self.is_connected = True
        self.q = queue.Queue()

    def connect(self):
        print(self.scope["url_route"]["kwargs"])
        self.room_name = self.scope["url_route"]["kwargs"]["room_name"]
        self.room_group_name = f"chat_{self.room_name}"

        if self.chat_log == None:
            self.start_chat()

        self.accept()

        # join the room group
        async_to_sync(self.channel_layer.group_add)(
            self.room_group_name,
            self.channel_name,
        )

    def start_chat(self):
        self.history_item = models.TestHistoryItem.objects.get(item_id=self.room_name)
        self.chat_log = models.ChatLog(test_history_item=self.history_item)
        self.chat_log.save()

        self.set_mode()

        thread_pool_manager.feed_queue(
            test_history_items=self.history_item, consumer=self
        )
        self.send_system_message(text="Readying session", style="warning", seconds=5)

    def set_mode(self):
        # TODO: add mode selection
        self.mode = "WHATSAPP"
        mode = models.TestModesModel.objects.get(options=self.mode)
        self.history_item.modes.add(mode)

    def disconnect(self, close_code):
        async_to_sync(self.channel_layer.group_discard)(
            self.room_group_name,
            self.channel_name,
        )
        self.send_system_message(text="Session ended", style="dark", seconds=5)
        self.is_connected = False

    def receive(self, text_data=None, bytes_data=None):
        """
        When using channel layer's group_send, your consumer has to have a method
        for every JSON message type you use. In our situation, type is equaled to chat_message.
        Thus, we added a method called chat_message.
        If you use dots in your message types, Channels will automatically
        convert them to underscores when looking for a method
        -- e.g, chat.message will become chat_message.
        """
        text_data_json = json.loads(text_data)

        if text_data_json["type"] == "chat_message":
            message = text_data_json["message"]
            self.q.put(message)

        if text_data_json["type"] == "command":
            command = text_data_json["payload"]

            if command == "end_session":
                self.is_connected = False

    def server_send(self, text: str, id: int, participant: str = None) -> None:
        """
        Since WebsocketConsumer is a synchronous consumer,
        we had to call async_to_sync when working with the channel layer.
        """
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                "type": "chat_message",
                "id": id,
                "message": text,
                "participant": participant,
            },
        )

    def chat_message(self, event):
        self.send(text_data=json.dumps(event))

    def send_system_message(self, text: str, style: str = None, seconds=int) -> None:
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                "type": "system_message",
                "message": text,
                "style": style,
                "seconds": seconds,
            },
        )

    def system_message(self, event):
        self.send(text_data=json.dumps(event))

    def send_command(self, payload: str):
        print("Sending command " + payload)
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                "type": "command",
                "payload": payload,
            },
        )

    def command(self, event):
        self.send(text_data=json.dumps(event))
