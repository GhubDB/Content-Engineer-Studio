from database.models import ChatLog, TestHistoryItem, TestModesModel
from django.shortcuts import render


def live_test(request, room_name):
    history_item = TestHistoryItem.objects.get(item_id=room_name)
    # chat_log, _ = ChatLog.objects.get_or_create(
    #     test_history_item=history_item, mode=mode
    # )
    # print("========================")
    # print(history_item.item_id)
    return render(
        request,
        "live_test.html",
        {
            "id": history_item.item_id,
        },
    )
