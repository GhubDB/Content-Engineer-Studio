Additional requirements:
Python
Docker Desktop
VNC Viewer (optional)
Node.js
npm install websocket
npm install react-router-dom
npm install @material-ui/core

Helpful VScode extensions:
SQLite3
Docker
Test Explorer UI
