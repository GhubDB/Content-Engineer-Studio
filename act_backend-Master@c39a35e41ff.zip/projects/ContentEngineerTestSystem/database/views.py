from django.contrib.auth.decorators import login_required
from django.http import Http404, JsonResponse
from django.shortcuts import render
from django.utils.decorators import method_decorator
from django.views.generic import TemplateView, UpdateView

from database.forms import PostForm
from database.models import Post


# Example for test purposes
class HomeView(TemplateView):
    template_name = "main/home.html"


# Example for test purposes
class AdminView(TemplateView):
    template_name = "main/admin.html"

    @method_decorator(login_required)
    def dispatch(self, request, *args, **kwargs):
        return super(AdminView, self).dispatch(request, *args, **kwargs)


# Example for test purposes
class PostUpdateView(UpdateView):
    model = Post
    form_class = PostForm
    template_name = "main/update.html"
    success_url = "/"

    def post(self, request, *args, **kwargs):
        if getattr(request.user, "first_name", None) == "Herbert":
            raise Http404()
        return super(PostUpdateView, self).post(request, *args, **kwargs)
