from django.forms import ModelForm, ValidationError

from database.models import Post


# Example for test purposes
class PostForm(ModelForm):
    class Meta:
        model = Post
        fields = ("body",)

    def clean_body(self):
        data = self.cleaned_data.get("body")
        if len(data) <= 5:
            raise ValidationError("Message is too short!")
        return data
