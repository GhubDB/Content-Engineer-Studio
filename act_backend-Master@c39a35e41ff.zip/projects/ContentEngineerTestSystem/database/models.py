import itertools
import uuid
from enum import Enum
from uuid import uuid4

import django.db.models.signals as signals
import pandas as pd
from django.conf import settings
from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin, User, UserManager
from django.contrib.auth.validators import ASCIIUsernameValidator
from django.db import models
from django.db.models import Q
from django.utils.translation import gettext as _
from django.utils.translation import gettext_lazy as _
from utility_functions.auto_repr_decorator import auto_repr
from utility_functions.slugify_random_title import test_object_pre_save

# from django.utils import timezone


# Example for test purposes
class Post(models.Model):
    body = models.TextField()

    def get_excerpt(self, char):
        return self.body[:char]


class BaseMetaDataClass(models.Model):
    """Base class for models with user interaction"""

    created_timestamp = models.DateTimeField(auto_now_add=True)
    updated_timestamp = models.DateTimeField(auto_now=True)
    created_userid = models.ForeignKey(
        "CustomUser", blank=True, null=True, on_delete=models.PROTECT
    )

    class Meta:
        abstract = True
        ordering = ["-created_timestamp"]

    # def get_created(self):
    #     return

    # def get_updated(self):
    #     return


class BaseConstantsClass(Enum):
    """
    Base class for classes that store constants used elsewhere in the application.
    Also used as choices in models.
    """

    @classmethod
    def choices(cls):
        return tuple((i.name, i.value) for i in cls)


class BaseConstantsModel(models.Model):
    class Meta:
        abstract = True

    @property
    def enum(self) -> Enum:
        """This method turns strings that are stored in the database back into Enums"""
        return self.cls(self.options)

    @classmethod
    def get_default(cls):
        return cls.objects.get_or_create(options="None")[0].pk

    def __str__(self) -> str:
        return self.options


class TestModes(BaseConstantsClass):
    NONE = "None"
    INT = "INT"
    SAM = "SAM"
    WHATSAPP = "WHATSAPP"


# https://stackoverflow.com/questions/54802616
class TestModesModel(BaseConstantsModel):
    cls = TestModes
    options = models.CharField(max_length=10, choices=cls.choices(), unique=True)


class Languages(BaseConstantsClass):
    NONE = "None"
    DE = "DE"
    EN = "EN"
    FR = "FR"
    IT = "IT"


class LanguagesModel(BaseConstantsModel):
    cls = Languages
    options = models.CharField(max_length=10, choices=cls.choices(), unique=True)


class Priority(BaseConstantsClass):
    NONE = "None"
    LOW = "LOW"  # _("Niedrig")
    MEDIUM = "MEDIUM"  # _("Mittel")
    CRITICAL = "CRITICAL"  # _("Kritisch")


class PriorityModel(BaseConstantsModel):
    cls = Priority
    options = models.CharField(max_length=10, choices=cls.choices(), unique=True)


class TestResult(BaseConstantsClass):
    NONE = "None"
    PASS = "PASS"
    MISMATCH = "MISMATCH"
    FAIL = "FAIL"


class TestResultModel(BaseConstantsModel):
    cls = TestResult
    options = models.CharField(max_length=10, choices=cls.choices(), unique=True)


class Quality(BaseConstantsClass):
    NONE = "None"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class QualityModel(BaseConstantsModel):
    cls = Quality
    options = models.CharField(max_length=10, choices=cls.choices(), unique=True)


class ImplementationStatus(BaseConstantsClass):
    NONE = "None"
    NOT_IMPLEMENTED = "NOT_IMPLEMENTED"
    IN_PROGRESS = "IN_PROGRESS"
    IMPLEMENTED = "IMPLEMENTED"


class ImplementationStatusModel(BaseConstantsModel):
    cls = ImplementationStatus
    options = models.CharField(max_length=15, choices=cls.choices(), unique=True)


class Topic(BaseConstantsClass):
    NONE = "None"
    ASSURANCE = "Assurance"
    FULFILLMENT = "Fulfillment"
    BILLING = "Billing"
    CANCELLATION = "Cancellation"
    SALES = "Sales"


class TopicModel(BaseConstantsModel):
    cls = Topic
    options = models.CharField(max_length=12, choices=cls.choices(), unique=True)


class Participant(BaseConstantsClass):
    NONE = "None"
    BOT = "Bot"
    USER = "User"


class ParticipantModel(BaseConstantsModel):
    cls = Participant
    options = models.CharField(max_length=10, choices=cls.choices(), unique=True)


class CustomUser(AbstractBaseUser, PermissionsMixin):
    username_validator = ASCIIUsernameValidator()

    user_id = models.CharField(max_length=255, unique=True, default=uuid.uuid4)
    username = models.CharField(
        _("username"),
        max_length=150,
        unique=True,
        help_text=_(
            "Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only."
        ),
        validators=[username_validator],
        error_messages={
            "unique": _("A user with that username already exists."),
        },
    )
    is_staff = models.BooleanField(
        _("staff status"),
        default=False,
        help_text=_("Designates whether the user can log into this admin site."),
    )
    is_active = models.BooleanField(
        _("active"),
        default=True,
        help_text=_(
            "Designates whether this user should be treated as active. Unselect this instead of deleting accounts."
        ),
    )
    first_name = models.CharField(_("first name"), max_length=150, blank=True)
    last_name = models.CharField(_("last name"), max_length=150, blank=True)
    email = models.EmailField(
        _("email address"),
        unique=True,
        error_messages={
            "unique": _("A user with that email address already exists."),
        },
        blank=True,
        null=True,
    )
    default_language = models.ForeignKey(
        LanguagesModel, blank=True, null=True, on_delete=models.SET_NULL
    )
    updated_timestamp = models.DateTimeField(auto_now=True)
    created_timestamp = models.DateTimeField(auto_now_add=True)

    USERNAME_FIELD = "username"
    EMAIL_FIELD = "email"

    class Meta:
        verbose_name = _("user")
        verbose_name_plural = _("users")

    objects = UserManager()

    def __str__(self):
        return self.username


class Media(BaseMetaDataClass):
    image = models.ImageField()


@auto_repr
class TestGroup(BaseMetaDataClass):
    group_id = models.CharField(max_length=25)
    group_name = models.CharField(max_length=100)

    def __str__(self):
        return self.group_name


@auto_repr
class Faq(BaseMetaDataClass):
    class WlineWless(models.TextChoices):
        WIRELINE = "WIRELINE", _("Wireline")
        WIRELESS = "WIRELESS", _("Wireless")

    # TODO: introduce FAQ history
    faq_id = models.CharField(max_length=30, unique=True)
    options = models.CharField(max_length=30, unique=True)
    topic = models.ForeignKey(
        TopicModel, blank=True, null=True, on_delete=models.SET_NULL
    )
    wline_wless = models.CharField(
        max_length=10, choices=WlineWless.choices, blank=True
    )
    question = models.TextField()
    answer = models.TextField()
    text_link = models.TextField()
    link = models.URLField(max_length=500)
    comment = models.TextField()
    language = models.ForeignKey(LanguagesModel, null=True, on_delete=models.SET_NULL)

    class Meta:
        ordering = ["pk"]

    def __str__(self):
        return self.options


@auto_repr
class Variant(BaseMetaDataClass):
    faq = models.ForeignKey(Faq, null=True, on_delete=models.CASCADE)
    question = models.TextField()
    language = models.ForeignKey(LanguagesModel, null=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.question


@auto_repr
class TestObject(BaseMetaDataClass):
    test_id = models.CharField(max_length=255, unique=True, default=uuid4)
    story_id = models.CharField(max_length=50, blank=True, null=True)
    topic = models.ForeignKey(
        TopicModel, default=TopicModel.get_default, null=True, on_delete=models.SET_NULL
    )
    language = models.ForeignKey(
        LanguagesModel,
        default=LanguagesModel.get_default,
        null=True,
        on_delete=models.SET_NULL,
    )
    implementation_status = models.ForeignKey(
        ImplementationStatusModel,
        default=ImplementationStatusModel.get_default,
        null=True,
        on_delete=models.SET_NULL,
    )
    correct_faq = models.ForeignKey(
        Faq, blank=True, null=True, on_delete=models.SET_NULL
    )
    # correct_flow = models.ForeignKey()
    priority = models.ForeignKey(
        PriorityModel,
        default=PriorityModel.get_default,
        null=True,
        on_delete=models.SET_NULL,
        verbose_name="Priorität",
    )
    in_progress = models.BooleanField(default=False)
    # TODO: add custom multiple choice
    # test_group = models.ManyToManyField(TestGroup, blank=True)

    def __str__(self):
        return self.test_id

    def get_most_recent_history_item(self):
        return (
            TestHistoryItem.objects.filter(test=self)
            .order_by("-updated_timestamp")
            .first()
        )

    def get_first_question(self):
        most_recent_item = self.get_most_recent_history_item()
        if not most_recent_item:
            return None
        questions = most_recent_item.get_questions()
        if questions:
            return questions[0]
        return ""


@auto_repr
class TestHistoryItem(BaseMetaDataClass):
    test = models.ForeignKey(TestObject, on_delete=models.CASCADE)
    item_id = models.CharField(max_length=255, unique=True, default=uuid.uuid4)
    is_live = models.BooleanField()
    modes = models.ManyToManyField(TestModesModel, blank=True)
    chat_logs = models.ManyToManyField("ChatLog", blank=True)
    actual_faq = models.ForeignKey(
        Faq, blank=True, null=True, on_delete=models.SET_NULL
    )
    test_quality = models.ForeignKey(
        QualityModel, default=QualityModel.get_default, on_delete=models.CASCADE
    )
    comment = models.TextField(blank=True, null=True)
    test_status = models.ForeignKey(
        TestResultModel,
        default=TestResultModel.get_default,
        null=True,
        on_delete=models.SET_NULL,
    )
    test_account = models.CharField(max_length=20, blank=True, null=True)
    errors = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.item_id

    def get_questions(self) -> list[str]:
        queryset = Questions.objects.filter(history_item=self).order_by("number")
        if not queryset:
            return []
        return [i.question for i in queryset]

    def add_chat_log(self, df: pd.DataFrame):
        chat_log = ChatLog(test_history_item=self)
        chat_log.save()
        counter = itertools.count().__next__
        for item in df.to_dict(orient="records"):
            p, _ = ParticipantModel.objects.get_or_create(options=item["Name"])
            chat_log.add_message(
                participant=p,
                chat_log=chat_log,
                number=item["Number"],
                sent_timestamp=item["Time"],
                message=item["Message"],
            )

            if (item["Name"] == Participant.USER.value) and self.is_live:
                Questions.objects.create(
                    history_item=self,
                    question=item["Message"],
                    number=counter(),
                )

    def add_questions(self, questions) -> None:
        # TODO: make a way to make questions iterable
        if not hasattr(questions, "__iter__") or isinstance(questions, str):
            questions = [questions]

        for idx, question in enumerate(questions):
            Questions.objects.create(history_item=self, question=question, number=idx)


@auto_repr
class Questions(BaseMetaDataClass):
    question_id = models.CharField(max_length=255, unique=True, default=uuid4)
    history_item = models.ForeignKey(
        TestHistoryItem, blank=True, null=True, on_delete=models.CASCADE
    )
    question = models.TextField()
    number = models.IntegerField()

    class Meta:
        ordering = ["number"]

    def __str__(self):
        return self.question


@auto_repr
class ChatLog(BaseMetaDataClass):
    test_history_item = models.ForeignKey(TestHistoryItem, on_delete=models.CASCADE)
    chat_log_id = models.CharField(max_length=255, unique=True, default=uuid4)
    mode = models.ForeignKey(
        TestModesModel,
        null=True,
        on_delete=models.SET_NULL,
    )

    def add_message(
        self,
        participant: str,
        chat_log: models.Model,
        number: str,
        sent_timestamp: str,
        message: str,
    ) -> None:
        party = ParticipantModel.objects.get(options=participant)
        message = ChatLogItem(
            participant=party,
            chat_log=chat_log,
            number=number,
            sent_timestamp=sent_timestamp,
            message=message,
        )
        message.save()


class ModelQuerySet(models.QuerySet):
    def search(self, query=None):
        if query is None or query == "":
            return self.none()

        lookups = Q(message__icontains=query) | Q(participant__icontains=query)
        return self.filter(lookups)


class ModelManager(models.Manager):
    def get_queryset(self):
        return ModelQuerySet(self.model, using=self._db)

    def search(self, query=None):
        return self.get_queryset().search(query=query)


@auto_repr
class ChatLogItem(models.Model):
    participant = models.ForeignKey(
        ParticipantModel, blank=True, null=True, on_delete=models.SET_NULL
    )
    chat_log = models.ForeignKey(ChatLog, on_delete=models.CASCADE)
    message_id = models.CharField(max_length=255, unique=True, default=uuid.uuid4)
    message = models.CharField(max_length=500)
    number = models.IntegerField()
    sent_timestamp = models.DateTimeField()
    message_quality = models.ForeignKey(
        QualityModel,
        default=QualityModel.get_default,
        null=True,
        on_delete=models.SET_NULL,
    )

    objects = ModelManager()

    class Meta:
        ordering = ["number"]

    def __str__(self):
        return self.message_id
