from django.apps import AppConfig


# Example for test purposes
class MainConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "database"
