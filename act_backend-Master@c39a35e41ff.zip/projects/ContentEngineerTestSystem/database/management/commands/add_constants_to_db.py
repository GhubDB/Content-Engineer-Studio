from typing import Any

from django.core.management.base import BaseCommand
from database.models import (
    ImplementationStatusModel,
    LanguagesModel,
    ParticipantModel,
    PriorityModel,
    QualityModel,
    TestModesModel,
    TestResultModel,
    TopicModel,
)


class Command(BaseCommand):
    help = "A command to add a database entry for each available choice in the model's field"

    def handle(self, *args: Any, **options: Any):
        models = [
            ImplementationStatusModel,
            LanguagesModel,
            ParticipantModel,
            PriorityModel,
            QualityModel,
            TestModesModel,
            TestResultModel,
            TopicModel,
        ]

        for model in models:
            for choice in model.options.field.choices:
                obj, _ = model.objects.get_or_create(options=choice[1])
                # obj = model(options=choice[1])
                obj.save()
