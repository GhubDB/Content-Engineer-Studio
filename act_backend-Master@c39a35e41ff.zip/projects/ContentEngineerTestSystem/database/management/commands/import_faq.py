import os
import traceback
from typing import Any

import pandas as pd
from database.models import Faq, LanguagesModel, TopicModel, Variant
from django.core.management.base import BaseCommand
from django.db.utils import IntegrityError


class Command(BaseCommand):
    help = "A command to add data from an Excel file to the database"

    def handle(self, *args: Any, **options: Any):
        data_file_path = os.path.join(os.path.dirname(__file__), "FAQs.xlsx")

        faqs = pd.read_excel(data_file_path, sheet_name="MASTER FAQ DE")

        lang = LanguagesModel.objects.get(options="DE")
        for row in faqs.to_dict(orient="records"):
            t, _ = TopicModel.objects.get_or_create(options=row["Cluster"])

            faq, _ = Faq.objects.get_or_create(
                faq_id=row["ID"],
                options=row["Name"],
                topic=t,
                wline_wless=row["Wireless / Wireline"],
                question=row["Question"],
                answer=row["Answer"],
                text_link=row["Text Link"],
                link=row["Link"],
                comment=row["Bemerkungen"],
                language=lang,
            )

        variants = pd.read_excel(data_file_path, sheet_name="Variants")
        for row in variants.to_dict(orient="records"):

            faq_id = Faq.objects.get(faq_id=row["ID"])
            variant = Variant.objects.get_or_create(
                faq=faq_id, question=row["W"], language=lang
            )


if __name__ == "__main__":
    comm = Command()
    comm.handle()
