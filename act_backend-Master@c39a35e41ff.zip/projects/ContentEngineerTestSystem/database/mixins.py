from rest_framework import permissions


class UserQuerySetMixin:
    """This mixin filters querysets to match only the currently logged in user"""

    user_field = "created_userid"

    def get_queryset(self, *args, **kwargs):
        lookup_data = {}
        lookup_data[self.user_field] = self.request.user
        qs = super().get_queryset(*args, **kwargs)
        return qs.filter(**lookup_data)
