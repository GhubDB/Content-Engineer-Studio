from django.contrib import admin

from . import models


# Example for test purposes
class PostAdmin(admin.ModelAdmin):
    model = models.Post
    list_display = ("excerpt",)

    def excerpt(self, obj):
        return obj.get_excerpt(5)


class TestObjectAdmin(admin.ModelAdmin):
    list_display = ["test_id", "topic", "language", "correct_faq"]


class TopicAdmin(admin.ModelAdmin):
    list_display = ["options"]


class LanguagesModelAdmin(admin.ModelAdmin):
    list_display = ["options"]


admin.site.register(models.TestObject, TestObjectAdmin)
admin.site.register(models.LanguagesModel, LanguagesModelAdmin)
admin.site.register(models.TopicModel, TopicAdmin)
admin.site.register(models.TestHistoryItem)
admin.site.register(models.Questions)
admin.site.register(models.ChatLog)
admin.site.register(models.QualityModel)
admin.site.register(models.TestModesModel)
admin.site.register(models.Post, PostAdmin)
