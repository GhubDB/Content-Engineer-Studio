import datetime

import pandas as pd
from django.utils import timezone
from test_runner.data.constants import ImportTests

from database import models


def set_in_progress(history_item: models.TestHistoryItem, status: bool) -> None:
    testobj = models.TestObject.objects.get(pk=history_item.test.id)
    testobj.in_progress = status
    testobj.save()


def get_most_recent_chat_log(item_id):
    chat_log = (
        models.ChatLog.objects.filter(test_history_item__item_id__exact=item_id)
        .order_by("-created_timestamp")
        .first()
    )
    return models.ChatLogItem.objects.filter(chat_log=chat_log).order_by("number")


def get_mytimezone_date(original_datetime):
    # https://stackoverflow.com/questions/60561928
    tz = timezone.get_current_timezone()
    timzone_datetime = timezone.make_aware(original_datetime, tz, True)
    return timzone_datetime


def process_template(template_file):
    df = pd.read_excel(template_file, sheet_name="template")
    return make_testobj(df)


def make_testobj(df: pd.DataFrame):
    # TODO: add userid, testaccount and additional modes
    test_objs = []
    mode, _ = models.TestModesModel.objects.get_or_create(
        options=models.TestModes.WHATSAPP.value
    )
    userid, _ = models.CustomUser.objects.get_or_create(username="Tester")

    for row in df.to_dict(orient="records"):
        testobj = models.TestObject.objects.create(created_userid=userid)
        if row["story_id"]:
            testobj.story_id = row["story_id"]

        for col in [
            ["correct_faq", models.Faq],
            ["language", models.LanguagesModel],
            ["topic", models.TopicModel],
        ]:
            setattr(testobj, col[0], get_foreign_key_obj(row, col[0], col[1]))

        history_item = make_history_item(
            testobj=testobj, questions=row["questions"], mode=mode
        )

        testobj.save()
        history_item.save()
        test_objs.append(testobj)

    return test_objs


def get_foreign_key_obj(row, field_name: str, cls):
    if row[field_name]:
        return cls.objects.get(options=row[field_name])


def make_history_item(
    testobj: models.TestHistoryItem, questions, mode
) -> models.TestHistoryItem:
    history_item = models.TestHistoryItem.objects.create(test=testobj, is_live=False)
    history_item.add_questions(questions=questions)
    history_item.modes.add(mode)
    return history_item
