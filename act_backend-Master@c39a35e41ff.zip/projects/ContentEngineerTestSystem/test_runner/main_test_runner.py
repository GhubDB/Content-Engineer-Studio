import os
import queue

import django
from database import services

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from database.models import BaseConstantsClass, TestHistoryItem, TestModes

# from test_runner.engines.int_engine import IntEngine
from test_runner.engines.sam_engine import SamEngine
from test_runner.engines.whatsapp_engine import WhatsAppEngine


class TestRunner:
    """This class manages individual tests and runs them in different modes (Whatsapp / Int / Vega / etc.)"""

    def __init__(self, modes: list[BaseConstantsClass]) -> None:
        self.modes = modes
        self.engines = {
            # TestModes.INT: IntEngine,
            TestModes.SAM: SamEngine,
            TestModes.WHATSAPP: WhatsAppEngine,
        }
        self.init_engines()

    def init_engines(self):
        for mode in self.modes:
            engine = self.engines[mode.enum]()
            self.engines[mode.enum] = engine

    def run_test(self, test_history_item: TestHistoryItem) -> bool:
        questions = test_history_item.get_questions()
        for mode in self.modes:
            engine = self.engines[mode.enum]
            with engine.manager():
                engine.ask_questions(questions)
                chat_log = engine.get_chat_log()
                test_history_item.add_chat_log(chat_log)

        services.set_in_progress(test_history_item, status=False)
        return test_history_item

    def start_live_chat(self, prioritized_item) -> bool:
        engine = self.engines[self.modes[0].enum]
        with engine.manager():
            engine.live_chat_loop(prioritized_item=prioritized_item)
            chat_log = engine.get_chat_log()
            prioritized_item.item.add_chat_log(chat_log)
            prioritized_item.consumer.send_command(payload="get_chat_log")

        services.set_in_progress(prioritized_item.item, status=False)
        return prioritized_item.item


if __name__ == "__main__":
    pass
    # test_history_items = testobject_factory.testobj_factory(2)
    # for test_history_item in test_history_items:
    #     runner = TestRunner(modes=test_history_item.modes.all())
    #     runner.run_test(test_history_item)
