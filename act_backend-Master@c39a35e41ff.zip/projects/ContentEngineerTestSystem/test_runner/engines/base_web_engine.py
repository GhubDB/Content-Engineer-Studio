import time
from contextlib import contextmanager
from enum import Enum
from xml.dom import NotFoundErr

import pandas as pd
from selenium.webdriver.common.by import By
from test_runner.cets_selenium.selenium_helpers import Browser
from test_runner.data.constants import Keys, Selectors, Tags, Urls
from test_runner.engines.webscraping_daemon import WebscrapingDaemon
from utility_functions.logging_decorator import LoggingDecorator
from utility_functions.retry_decorator import retry


class BaseWebEngine:
    """
    Baseclass for web engines that handle sending and webscraping messages
    Uses the Browser class for most of its actions
    Methods is_ready and get_conversation_length
    have to be implemented by subclasses.
    """

    def __init__(self, mode: Enum):
        self.browser = Browser()
        self.mode = mode

    def start_engine(self, url: str = None):
        host = self.get_host_url()
        self.browser.set_up(host=host)

        url = self.get_test_mode_url()
        self.browser.get_url(url=url)

    def get_test_mode_url(self):
        return Urls.WEB[self.mode]

    def get_host_url(self):
        return Urls.HOST[self.mode]

    def get_selector(self):
        return Selectors.OPTIONS[self.mode]

    def stop_engine(self):
        return self.browser.tear_down()

    @LoggingDecorator.log
    @contextmanager
    def manager(self):
        try:
            self.start_engine()
            self.is_ready()
            yield

        finally:
            self.stop_engine()

    def is_ready(self) -> None:
        raise NotImplementedError

    def get_conversation_length(self):
        raise NotImplementedError

    def live_chat_loop(self, prioritized_item) -> None:
        consumer = prioritized_item.consumer
        questions = prioritized_item.item.get_questions()
        q = prioritized_item.consumer.q
        daemon = WebscrapingDaemon(engine=self, consumer=prioritized_item.consumer)

        try:
            if questions:
                self.ask_questions(questions)

            consumer.send_system_message(
                text="Session ready", style="success", seconds=2
            )
            question = ""
            while prioritized_item.consumer.is_connected:
                while not q.empty():
                    question = q.get()

                    if question == "":
                        continue

                    self.send_message(text=question)
                    time.sleep(0.25)

                time.sleep(0.1)

        except Exception as e:
            consumer.send_system_message(text=e, style="danger", seconds=60)

        finally:
            daemon.stop()

        return

    @retry(tries=2)
    def send_message(self, text: str) -> bool:
        selector = self.get_selector()
        target = Tags.TEXT_INPUT[self.mode]
        self.browser.send_input(target=target, text=text, selector=selector)
        self.browser.send_input(target=target, text=Keys.ENTER, selector=selector)
        return True

    def get_last_messages(self, number: int = None) -> list[str]:
        content = self.browser.get_element(
            target=Tags.MESSAGES_DIV[self.mode], seconds=30
        )

        if not content:
            raise NotFoundErr(f"Mode: {self.mode}, unable to find messages div")

        messages = content.find_elements(By.XPATH, Tags.TEXT_BUBBLE[self.mode])

        if number:
            return [message.text for message in messages[-number::]]

        return [message.text for message in messages]

    def ask_questions(self, questions: list[str]) -> None:
        for question in questions:
            self.send_message(question)
            self.await_response(question, timeout_in_seconds=60)

            # Need to wait in order to see if the bot sends more than one message
            time.sleep(15)

    def get_chat_log(
        self,
    ) -> pd.DataFrame:
        return self.browser.element_clickable(
            target=Tags.MESSAGES_DIV[self.mode], seconds=30
        )

    def await_response(
        self, last_sent_message: str, timeout_in_seconds: int = 40
    ) -> list:
        # Waits for a response from the bot and returns the last messages
        start = time.time()

        while time.time() - start <= timeout_in_seconds:
            if last_sent_message not in self.get_last_messages(number=1):
                print("last sent: " + last_sent_message)
                msg = self.get_last_messages(number=1)
                print("last message: " + msg[0])
                return self.get_last_messages(number=3)
            time.sleep(1)

        raise TimeoutError(
            f"Mode: {self.mode}, no response from the bot after {time.time() - start} seconds."
        )

    @staticmethod
    def make_dataframe(chat_log: list[tuple[str]]) -> pd.DataFrame:
        return pd.DataFrame(chat_log, columns=["Number", "Time", "Name", "Message"])
