# from test_runner.engines.base_web_engine import BaseWebEngine


class SamEngine:
    # def __init__(self):
    #     self.mode = TestModes.SAM
    #     super().__init__(self.mode)
    pass
