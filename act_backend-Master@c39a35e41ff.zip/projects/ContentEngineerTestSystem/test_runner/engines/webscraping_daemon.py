import time
from asyncio import Event
from threading import Thread

from test_runner.data.constants import EndMessages


class WebscrapingDaemon(Thread):
    """This class handles sending chat messages to the live chat component on the front end"""

    def __init__(
        self,
        engine,
        consumer,
    ) -> None:
        Thread.__init__(self)
        self.engine = engine
        self.consumer = consumer
        self.length = 0
        self.daemon = True
        self._stop_event = Event()
        self.running: bool = True
        self.start()

    def stop(self) -> None:
        self.running = False
        self._stop_event.set()

    def stopped(self) -> bool:
        return self._stop_event.is_set()

    def __len__(self) -> int:
        return self.length

    def run(self) -> None:
        while self.running:
            df = self.engine.get_chat_log()
            new_len = df.shape[0]
            if new_len > self.length:
                for i in range(self.length, df.shape[0]):
                    # TODO: add other fields such as time/name to sent message
                    # Format: ["Number", "Time", "Name", "Message"]
                    self.consumer.server_send(
                        text=df.loc[i, "Message"],
                        participant=df.loc[i, "Name"],
                        id=i,
                    )

                self.length = df.shape[0]
            time.sleep(0.2)
