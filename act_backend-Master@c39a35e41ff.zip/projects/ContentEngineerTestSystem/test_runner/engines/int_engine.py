# import os
# import time

# import django

# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
# django.setup()

# from main.models import TestModes
# from test_runner.data.constants import Tags

# from test_runner.engines.base_web_engine import BaseWebEngine


# class IntEngine(BaseWebEngine):
#     def __init__(self):
#         self.mode = TestModes.INT
#         super().__init__(self.mode)

#     def is_ready(self, seconds: int = 45) -> None:
#         target = Tags.TEXT_INPUT[self.mode]
#         if self.browser.element_clickable(target=target, seconds=seconds):
#             return True


# if __name__ == "__main__":
#     engine = IntEngine(mode=TestModes.INT)
#     with engine.manager():
#         assert engine.is_ready()
#         time.sleep(3)
#         engine.send_message(text="test text")
#         last_message = engine.get_last_messages(number=1)
#         assert last_message[0] == "test text"
#         engine.await_response(last_sent_message="test text", timeout_in_seconds=60)
# print(engine.get_chat_log())
