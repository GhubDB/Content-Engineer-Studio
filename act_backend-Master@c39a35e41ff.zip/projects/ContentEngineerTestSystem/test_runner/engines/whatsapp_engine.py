import os
import re
import time
from datetime import datetime

import django
from utility_functions.logging_decorator import LoggingDecorator

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from contextlib import contextmanager

import pandas as pd
from bs4 import BeautifulSoup as bs4
from database import services
from database.models import Participant, TestModes
from selenium.webdriver.common.by import By
from test_runner.data.constants import EndMessages, Keys, Tags
from test_runner.engines.base_web_engine import BaseWebEngine
from utility_functions.retry_decorator import retry


class WhatsAppEngine(BaseWebEngine):
    def __init__(self):
        super().__init__(mode=TestModes.WHATSAPP)

    @LoggingDecorator.log
    @contextmanager
    def manager(self):
        try:
            self.start_engine()
            self.is_ready()
            yield
            self.end_conversation()

        finally:
            self.stop_engine()

    def is_ready(self, seconds=45) -> bool:
        target = Tags.TEXT_INPUT[self.mode]
        if self.browser.element_clickable(
            target=target, seconds=seconds, selector=By.CSS_SELECTOR
        ):
            last_messages = self.get_last_messages(number=2)

            # Check if one of the last two received messages is a session closed message
            if set(last_messages).intersection(EndMessages.ALL):
                return True

            if last_messages[0] == Keys.END:
                time.sleep(20)

            # Send session close message and wait for session closed message response from bot
            counter = 0
            while counter < 2:
                last_message = self.get_last_messages(number=1)
                if last_message[0] in EndMessages.ALL:
                    return True

                if last_message[0] not in ["end", ""]:
                    self.send_message(text=Keys.END)

                response = set(self.await_response(Keys.END))
                if response.intersection(EndMessages.ALL):
                    return True

                counter += 1
                time.sleep(20)

        raise TimeoutError(
            f"Mode: {self.mode}, unable to terminate current chat session"
        )

    def end_conversation(self) -> None:
        message = self.get_last_messages(number=1)
        if message[0] not in [EndMessages.ALL, "end"]:
            self.send_message(text=Keys.END)

        time.sleep(2)

    def get_chat_log(
        self,
    ) -> pd.DataFrame:
        """
        Extracts the chat log from the page HTML and turns it into a Pandas df
        """
        if not super().get_chat_log():
            return []

        soup = bs4(self.browser.driver.page_source, "html.parser")
        messages_div = soup.find("div", {"class": "_3K4-L"})
        time_date_name = messages_div.find_all("div", {"class": "copyable-text"})
        message_list = [message.get_text() for message in time_date_name]

        chat_len = self.get_conversation_length(message_list)
        if not chat_len > 0:
            return pd.DataFrame()

        chat_log = self.make_chat_log(time_date_name, chat_len, message_list)
        return self.make_dataframe(chat_log=chat_log)

    def make_chat_log(self, time_date_name, chat_len, message_list) -> list[tuple[str]]:
        chat_log = []
        for i, (tags, message) in enumerate(
            zip(time_date_name[-chat_len:], message_list[-chat_len:])
        ):
            split_tags = self.split_time_date_name(message=tags["data-pre-plain-text"])
            chat_log_item = (str(i), *split_tags, message)
            chat_log.append(chat_log_item)
        return chat_log

    def get_conversation_length(self, messages: list) -> int:
        chat_len = 0
        for message in reversed(messages):
            if message in EndMessages.ALL:
                return chat_len
            chat_len += 1
        raise (f"Mode: {self.mode}, unable to find conversation length")

    def split_time_date_name(self, message: str) -> list:
        """
        The input for this function looks like this:
        "[06:20, 11.6.2022] Swisscom:"
        The below regex splits on '] '
        """
        split_tags = re.split(r"\]\s", message[1:-2].strip())
        # https://docs.python.org/3/library/datetime.html#strftime-strptime-behavior
        split_tags[0] = services.get_mytimezone_date(
            datetime.strptime(split_tags[0], "%H:%M, %d.%m.%Y")
        )
        split_tags[1] = (
            Participant.BOT.value if "BOT" in split_tags[1] else Participant.USER.value
        )
        return split_tags


if __name__ == "__main__":
    engine = WhatsAppEngine()
    with engine.manager():
        assert engine.is_ready()
        time.sleep(3)
        engine.send_message(text="test text")
        last_message = engine.get_last_messages(number=1)
        assert last_message[0] == "test text"
        engine.await_response(last_sent_message="test text", timeout_in_seconds=60)
        print(engine.get_chat_log())
