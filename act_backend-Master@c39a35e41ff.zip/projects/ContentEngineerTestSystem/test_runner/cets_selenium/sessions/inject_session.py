import os
import time
import traceback

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

options = webdriver.ChromeOptions()
options.add_argument("--ignore-ssl-errors=yes")
options.add_argument("--ignore-certificate-errors")

INJECT_SESSION = """
function getResultFromRequest(request) {
    return new Promise((resolve, reject) => {
        request.onsuccess = function(event) {
            resolve(request.result);
        };
    })
}

async function getDB() {
    var request = window.indexedDB.open("wawc");
    return await getResultFromRequest(request);
}

async function injectSession(SESSION_STRING) {
    var session = JSON.parse(SESSION_STRING);
    var db = await getDB();
    var objectStore = db.transaction("user", "readwrite").objectStore("user");
    for(var keyValue of session) {
        var request = objectStore.put(keyValue);
        await getResultFromRequest(request);
    }
}

await injectSession(arguments[0]);
"""


def sessionOpener(sessionFilePath):

    # 2.1 Verify that session file is exist
    if sessionFilePath == "":
        raise IOError('"' + sessionFilePath + '" is not exist.')

    # 2.2 Read the given file into "session" variable
    with open(sessionFilePath, "r", encoding="utf-8") as sessionFile:
        session = sessionFile.read()

    # 2.3 Open Chrome browser
    browser = webdriver.Remote(
        command_executor="http://localhost:4444/wd/hub", options=options
    )

    # 2.4 Open Web Whatsapp
    browser.get("https://web.whatsapp.com/")

    # 2.5 Wait for Web Whatsapp to be loaded properly
    # _wait_for_presence_of_an_element(browser, QR_CODE)
    target = """//*[@id="app"]/div/div/div[2]/div[1]/div/div[2]/div/canvas"""
    WebDriverWait(browser, 30).until(EC.presence_of_element_located((By.XPATH, target)))

    try:
        # 2.6 Execute javascript in browser to inject
        # session by using vaarible "session"
        print("Injecting session...")
        browser.execute_script(INJECT_SESSION, session)

        # 2.7 Refresh the page
        browser.refresh()
    except:
        traceback.print_exc()
    finally:
        # 1.7 Close the browser
        # input("Press enter to close browser.")
        browser.quit()

    # 2.8 Ask for user to enter any key to close browser
    # input("Press enter to close browser.")


sessionFilePath = r"C:\\Users\\tzhdimo1\\OneDrive - Swisscom\\content_engineer_test_system\\projects\\ContentEngineerTestSystem\\cets_selenium\\sessions\session.wa"

sessionOpener(sessionFilePath)
