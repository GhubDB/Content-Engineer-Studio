import os
import sys
import time
import traceback

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# https://www.geeksforgeeks.org/share-whatsapp-web-without-scanning-qr-code-using-python/


# Extract sessions from IndexedDB:

EXTRACT_SESSION = """
function getResultFromRequest(request) {
	return new Promise((resolve, reject) => {
		request.onsuccess = function (event) {
			resolve(request.result);
		};
	});
}

async function getDB() {
	var request = window.indexedDB.open("wawc");
	return await getResultFromRequest(request);
}

async function readAllKeyValuePairs() {
	var db = await getDB();
	var objectStore = db.transaction("user").objectStore("user");
	var request = objectStore.getAll();
	return await getResultFromRequest(request);
}

session = await readAllKeyValuePairs();
return JSON.stringify(session)
"""
# console.log(session);


# Now we get those key-value pairs as text by running the following line of code.
"""JSON.stringify(session);"""

options = webdriver.ChromeOptions()
options.add_argument("--ignore-ssl-errors=yes")
options.add_argument("--ignore-certificate-errors")


def sessionGenerator(sessionFilePath):
    # 1.1 Open Chrome browser
    # browser = webdriver.Chrome()
    try:
        browser = webdriver.Remote(
            command_executor="http://localhost:4444/wd/hub", options=options
        )

        # 1.2 Open Web Whatsapp
        browser.get("https://web.whatsapp.com/")

        # 1.3 Ask user to scan QR code
        print("Waiting for QR code scan...")

        # 1.4 Wait for QR code to be scanned
        target = """//*[@id="side"]/div[1]/div/label/div/div[2]"""
        WebDriverWait(browser, 30).until(
            EC.presence_of_element_located((By.XPATH, target))
        )
        # 1.5 Execute javascript in browser and
        # extract the session text
        session = browser.execute_script(EXTRACT_SESSION)

        # 1.6 Save file with session text file with
        # custom file extension ".wa"
        with open(sessionFilePath, "w", encoding="utf-8") as sessionFile:
            sessionFile.write(str(session))

        print("Your session file is saved to: " + sessionFilePath)
    except:
        traceback.print_exc()
    finally:
        # 1.7 Close the browser
        browser.quit()


# Taked session file path as command line
# argument and passed to following method
# sessionFilePath = os.getcwd()
# print(os.getcwd())
# sessionFilePath = r"C:\Users\tzhdimo1\OneDrive - Swisscom\content_engineer_test_system\projects\ContentEngineerTestSystem\cets_selenium\sessions\\"

sessionFilePath = r"C:\\Users\\tzhdimo1\\OneDrive - Swisscom\\content_engineer_test_system\\projects\\ContentEngineerTestSystem\\cets_selenium\\sessions\session.wa"
sessionGenerator(sessionFilePath)
