from bs4 import BeautifulSoup


def extract_text(soup_obj, tag, attribute_name, attribute_value):
    txt = soup_obj.find(tag, {attribute_name: attribute_value}).text().strip()
    if not txt:
        return False
    return txt
