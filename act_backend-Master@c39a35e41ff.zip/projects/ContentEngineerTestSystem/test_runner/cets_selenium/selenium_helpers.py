from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from test_runner.data.constants import Data


class SeleniumErrorHandler(Exception):
    pass


class Browser:
    def __init__(self) -> None:
        self.driver = None
        self.options = webdriver.ChromeOptions()
        # options.add_argument("--ignore-ssl-errors=yes")
        # options.add_argument("--ignore-certificate-errors")
        self.options.add_argument(Data.USER_DATA_DIR)
        self.options.add_argument(Data.PROFILE_DIR)
        # options.add_experimental_option("excludeSwitches", ["enable-automation"])
        # options.add_experimental_option("useAutomationExtension", False)

    def set_up(self, host: str):
        self.driver = webdriver.Remote(command_executor=host, options=self.options)

    def get_url(self, url) -> bool:
        self.driver.get(url)

    def tear_down(self) -> bool:
        self.driver.quit()

    def expose_url(self) -> str:
        return self.driver.current_url

    def refresh(self) -> None:
        self.driver.refresh()

    def element_clickable(self, target: str, seconds: int = 30, selector=By.XPATH):
        if WebDriverWait(self.driver, seconds).until(
            EC.element_to_be_clickable((selector, target))
        ):
            return True
        return False

    def get_element(self, target: str, seconds: int = 30, selector=By.XPATH):
        return WebDriverWait(self.driver, seconds).until(
            EC.element_to_be_clickable((selector, target))
        )

    def click_element(self, target: str, selector=By.XPATH) -> bool:
        element = self.driver.find_element(selector, target)
        element.click()

    def send_input(self, target: str, text: str, selector=By.XPATH) -> bool:
        self.driver.find_element(selector, target).send_keys(text)


if __name__ == "__main__":
    browser = Browser()
    browser.set_up(host="http://localhost:4444/wd/hub")
    browser.get_url(url="https://web.whatsapp.com/send?phone=+41800800800")
    print(browser.expose_url())
    print(
        browser.element_clickable(
            target="""//*[@id="main"]/footer/div[1]/div/span[2]/div/div[2]/div[1]/div/div[2]""",
            seconds=45,
        )
    )
    input("close?")
    browser.driver.quit()
