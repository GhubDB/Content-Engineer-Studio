import os
import queue
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, as_completed, wait
from dataclasses import dataclass, field
from threading import Event, Thread
from typing import Any

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()
from database import models, services
from database.models import TestHistoryItem
from tests.testobject_factory import testobj_factory
from utility_functions.logging_decorator import LoggingDecorator

from test_runner.data.constants import Settings
from test_runner.main_test_runner import TestRunner


@dataclass(order=True)
class PrioritizedItem:
    priority: int
    item: Any = field(compare=False)
    consumer: Any = None


class ThreadPoolManager(Thread):
    """
    This class runs test sessions in threads
    It manages the priority queue of test questions
    and live chat sessions
    https://stackoverflow.com/questions/41648103

    How to kill the thread:
    https://stackoverflow.com/questions/323972/
    """

    def __init__(self) -> None:
        self.q = queue.PriorityQueue()
        Thread.__init__(self)
        self.daemon = True
        self._stop_event = Event()
        self.running: bool = True
        self.start()

    def feed_queue(
        self,
        test_history_items: list[TestHistoryItem],
        consumer=None,
    ) -> None:

        if not hasattr(test_history_items, "__iter__"):
            test_history_items = [test_history_items]

        # Feeds the jobs queue with jobs and assigns priorities
        for history_item in test_history_items:
            services.set_in_progress(history_item, status=True)

            # Live test, high priority
            if history_item.is_live:
                self.q.put(
                    PrioritizedItem(priority=10, item=history_item, consumer=consumer)
                )
                return

            self.q.put(PrioritizedItem(priority=1, item=history_item))

    @LoggingDecorator.log
    def manage(self, prioritized_item: PrioritizedItem) -> TestHistoryItem:
        runner = TestRunner(modes=prioritized_item.item.modes.all())
        if prioritized_item.item.is_live:
            return runner.start_live_chat(prioritized_item=prioritized_item)
        return runner.run_test(test_history_item=prioritized_item.item)

    def stop(self) -> None:
        self.running = False
        self._stop_event.set()

    def stopped(self) -> bool:
        return self._stop_event.is_set()

    def run(self) -> None:
        with ThreadPoolExecutor(max_workers=Settings.NUM_WORKERS) as executor:

            # start a future for a thread which sends work in through the queue
            chat_sessions = {}

            while self.running:
                # check for status of the futures which are currently working
                done, not_done = wait(
                    chat_sessions, timeout=0.25, return_when=FIRST_COMPLETED
                )

                # if there is incoming work, start a new future
                while not self.q.empty():
                    prioritized_item = self.q.get()
                    test_history_item = prioritized_item.item

                    # Start the load operation and mark the future with its test_history_item
                    chat_sessions[
                        executor.submit(self.manage, prioritized_item)
                    ] = test_history_item.item_id

                # process any completed futures
                for future in done:
                    future_item_id = chat_sessions[future]
                    try:
                        test_history_item = future.result()
                    except Exception as e:
                        test_history_item.errors = "%r generated an exception: %s" % (
                            future_item_id,
                            e,
                        )
                        services.set_in_progress(test_history_item, status=False)
                        print(test_history_item.errors)
                    else:
                        print(f"Done with {test_history_item.item_id}")

                    finally:
                        # remove the now completed future
                        del chat_sessions[future]


thread_pool_manager = ThreadPoolManager()


if __name__ == "__main__":

    test_history_items = testobj_factory(1)
    thread_pool_manager.feed_queue(test_history_items)
    input("quit?")
    thread_pool_manager.stop()
    thread_pool_manager.join()
    print("ended")
