import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()
from database.models import TestModes
from selenium.webdriver.common.by import By


class Data:
    LOCALHOST_CHROME = "http://localhost:4444/wd/hub"
    LOCALHOST_FIREFOX = "http://localhost:4446/wd/hub"

    USER_DATA_DIR = r"--user-data-dir=/tmp/.com.google.Chrome.xi2T9x"
    PROFILE_DIR = r"--profile-directory=Default"


class EndMessages:
    """
    These messages are sent by the bot if a session is closed
    """

    ALL = {
        "Ich habe Ihre Anfrage geschlossen. Falls Sie doch noch Unterstützung benötigen, können Sie uns gerne wieder schreiben.",
        "J'ai fermé votre demande. Si vous avez besoin d'aide, s'il vous plaît ne hésitez pas à nous recontacter.",
        "Ho chiuso la vostra richiesta. Se ha ancora bisogno di supporto, si senta libero di contattarci di nuovo.",
        "I have closed your request. If you still need support, feel free to contact us again.",
        # "Chat technically ended because of end configuration",
        "I have closed your request. See you again soon.",
    }

    USER_TERMINATION = {
        "Ich habe Ihre Anfrage geschlossen. Falls Sie doch noch Unterstützung benötigen, können Sie uns gerne wieder schreiben.",
        "J'ai fermé votre demande. Si vous avez besoin d'aide, s'il vous plaît ne hésitez pas à nous recontacter.",
        "Ho chiuso la vostra richiesta. Se ha ancora bisogno di supporto, si senta libero di contattarci di nuovo.",
        "I have closed your request. If you still need support, feel free to contact us again.",
    }


class Settings:
    NUM_WORKERS = 5


class Keys:
    END = "end"
    ENTER = "\ue007"


class Urls:
    WEB = {
        TestModes.INT: "http://sisccpdice01:8013/dice-chat/webchat/",
        TestModes.SAM: "https://www.swisscom.ch/de/privatkunden.html",
        TestModes.WHATSAPP: "https://web.whatsapp.com/send?phone=+41800800800",
    }

    HOST = {
        TestModes.INT: "http://localhost:5555/wd/hub",
        TestModes.SAM: "http://localhost:5555/wd/hub",
        TestModes.WHATSAPP: "http://localhost:4445/wd/hub",
    }


class Selectors:
    OPTIONS = {TestModes.WHATSAPP: By.CSS_SELECTOR}


class Tags:
    MESSAGES_DIV = {
        TestModes.INT: """//*[@id="chatcontainer"]""",
        TestModes.SAM: """//*[@id="page-c4399c80c9"]/magic-help-button//chat-component//div/perfect-scrollbar/div/div[1]/div""",
        TestModes.WHATSAPP: """//*[@id="main"]/div[3]/div/div[2]""",
    }

    TEXT_BUBBLE = {
        TestModes.INT: "//*[contains(@class, 'container-bot') or contains(@class, 'container-user')]",
        TestModes.SAM: "ng-star-inserted",  # class name
        TestModes.WHATSAPP: "//*[contains(@class, 'selectable-text copyable-text')]",
    }

    TEXT_INPUT = {
        TestModes.INT: """//*[@id="message"]""",
        TestModes.SAM: "message__field text-small ng-untouched ng-pristine ps ng-valid",  # class contains / tag: <textarea
        TestModes.WHATSAPP: "[title*='Schreib eine Nachricht']",
    }

    # SAM only
    MAGIC_BUTTON = "magic-help-button"  # class contains
    TIMESTAMP = "display-block text-smaller text-align-right margin-bottom-0 ng-star-inserted"  # class name
    CLOSE_BUTTON = (
        "button button-reset transparent sdx-light-theme"  # class name / tag: <button
    )
    CHAT_BEENDEN = (
        "button button-reset primary sdx-light-theme"  # class name / tag: <button
    )


class WhatsAppSessions:
    MOBILES = {
        1: "0795241425",
        2: "0795202978",
        3: "0795227413",
        4: "0795230090",
        5: "0795174782",
    }

    LOCALHOSTS = {
        1: "http://localhost:4444/wd/hub",  # 0795241425, 5900 naughty_mclaren
        2: "http://localhost:4445/wd/hub",  # 0795202978, 5901 inspiring_easley
        3: "http://localhost:4446/wd/hub",  # 0795227413, 5902 wonderful_allen
        4: "http://localhost:4447/wd/hub",  # 0795230090, 5903 affectionate_germain -> no whitelist
        5: "http://localhost:4448/wd/hub",  # 0795174782, 5904 eager_shannon -> no whitelist
    }


class ImportTests:
    COLUMNS = [
        "questions",
        "correct_faq",
        "language",
        "topic",
        "story_id",
        "test_account",
    ]
