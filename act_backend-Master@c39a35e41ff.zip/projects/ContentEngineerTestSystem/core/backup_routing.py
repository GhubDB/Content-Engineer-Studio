# from channels.auth import AuthMiddlewareStack
# from channels.routing import ProtocolTypeRouter, URLRouter
# from websockets import routing

# # YT Build an Asynchronous Chatroom with Django and Channels

# application = ProtocolTypeRouter(
#     {
#         "websocket": AuthMiddlewareStack(URLRouter(routing.websocket_urlpatterns)),
#     }
# )
