import pytest
from database.views import AdminView, HomeView, PostUpdateView
from django.contrib.auth.models import AnonymousUser
from django.http import Http404
from django.test import RequestFactory
from mixer.backend.django import mixer

pytestmark = pytest.mark.django_db


class TestHomeView:
    def test_anonymous_user_can_access_page(self):
        req = RequestFactory().get("/")

        # instantiate home view and pass in the request
        resp = HomeView.as_view()(req)
        assert resp.status_code == 200, "Should be callable by anyone"


class TestAdminView:
    def test_anonymous_user_can_not_access(self):
        req = RequestFactory().get("/")
        req.user = AnonymousUser()
        resp = AdminView.as_view()(req)

        # Here, we test if the url in the response contains 'login'
        # example.com/login/auth
        assert "login" in resp.url

    def test_logged_in_user_can_access(self):
        user = mixer.blend("auth.User", is_superuser=True)
        req = RequestFactory().get("/")
        req.user = user
        resp = AdminView.as_view()(req)
        assert resp.status_code == 200, "Authenticated user can access"


class TestPostUpdateView:
    def test_get(self):
        req = RequestFactory().get("/")
        obj = mixer.blend("database.Post")
        resp = PostUpdateView.as_view()(req, pk=obj.pk)
        assert resp.status_code == 200, "Should be callable by anyone"

    def test_post(self):
        # Fill in random text
        post = mixer.blend("database.Post")

        # Attach data to the post request and fill body with specific text
        data = {"body": "New Body Text!"}
        req = RequestFactory().post("/", data=data)
        req.user = AnonymousUser()
        resp = PostUpdateView.as_view()(req, pk=post.pk)
        assert resp.status_code == 302, "Should redirect to success view"
        post.refresh_from_db()
        assert post.body == "New Body Text!", "Should update the post"

    def test_security(self):
        user = mixer.blend("auth.User", first_name="Herbert")
        post = mixer.blend("database.Post")
        req = RequestFactory().post("/", data={})
        req.user = user
        with pytest.raises(Http404):
            PostUpdateView.as_view()(req, pk=post.pk)
