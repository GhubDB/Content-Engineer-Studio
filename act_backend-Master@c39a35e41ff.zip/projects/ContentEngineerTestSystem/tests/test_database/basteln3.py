# class DummyClass:
#     def __init__(self):
#         print("mark")

#     def bla(self):
#         print("bla")


# def inst():
#     classes = {"dummy": DummyClass}

#     instance = classes["dummy"]()
#     instance.bla()


# if __name__ == "__main__":
#     inst()

import os

import django

# from tests.main.testobj_factory import testobj_factory

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()
from database.models import ChatLog, TestHistoryItem, TestModesModel

# from main.models import TestModes, TestModesModel


# def enum_from_str():
#     # enum = TestModes("WHATSAPP")
#     # print(type(enum))
#     # test_history_items = testobj_factory(1)
#     # modes = test_history_items[0].modes.all()
#     # print(modes[0].options)

#     obj = TestModesModel.objects.get(options="INT")
#     return obj.enum

# print(type(enum_from_str()))

# import re
# from datetime import datetime


# def whatsapp_split():
#     text = "[06:20, 11.6.2022] Swisscom:"
#     split_tags = re.split(r"\]\s", text[1:-1])
#     split_tags[0] = datetime.strptime(split_tags[0], "%I:%M, %d.%m.%Y")
#     return split_tags


# def clean_participant_data():
#     split_tags = whatsapp_split()
#     return "Bot" if split_tags[1] == "Swisscom" else "User"


# if __name__ == "__main__":
#     print(whatsapp_split())
#     print(clean_participant_data())


if __name__ == "__main__":

    test_id = "8e5452c1-6524-4881-ac12-1446e524ce76"

    # queryset = TestHistoryItem.get_first_chat_log(
    # )
    # print(queryset)
    mode = TestModesModel.objects.get(options="WHATSAPP")
    history_item = TestHistoryItem.objects.get(item_id=test_id)
    chat_log, _ = ChatLog.objects.get_or_create(
        test_history_item=history_item, mode=mode
    )
    print(chat_log)
