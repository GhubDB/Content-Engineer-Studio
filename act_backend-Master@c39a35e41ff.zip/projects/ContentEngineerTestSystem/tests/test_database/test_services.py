import os

import mock
import pandas as pd
import pytest
from database import models, services
from django.db.models import Q
from mixer.backend.django import mixer

pytestmark = pytest.mark.django_db


def prepare_database():
    data_file_path = os.path.join(os.path.dirname(__file__), "FAQs.xlsx")

    faqs = pd.read_excel(data_file_path, sheet_name="MASTER FAQ DE")

    lang, _ = models.LanguagesModel.objects.get_or_create(options="DE")
    for row in faqs.to_dict(orient="records"):
        t, _ = models.TopicModel.objects.get_or_create(options=row["Cluster"])

        faq, _ = models.Faq.objects.get_or_create(
            faq_id=row["ID"],
            options=row["Name"],
            topic=t,
            wline_wless=row["Wireless / Wireline"],
            question=row["Question"],
            answer=row["Answer"],
            text_link=row["Text Link"],
            link=row["Link"],
            comment=row["Bemerkungen"],
            language=lang,
        )


class TestServices:
    def test_can_create_database_entries_from_uploaded_file(self):
        prepare_database()
        data_file_path = os.path.join(
            os.path.dirname(__file__), "Test_Import_Template.xlsx"
        )
        df = pd.read_excel(data_file_path, sheet_name="template")
        objs = services.make_testobj(df)
