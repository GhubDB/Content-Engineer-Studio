from datetime import datetime, timedelta

import mock
import pytest
from mixer.backend.django import mixer

pytestmark = pytest.mark.django_db
from database import models, services
from django.db.models import Q
from django.utils import timezone
from test_runner.engines.base_web_engine import BaseWebEngine
from tests import testobject_factory


def make_chat_log():
    return [
        ("0", datetime.now(), models.Participant.BOT.value, "Success?"),
        ("1", datetime.now(), models.Participant.USER.value, "Question added?"),
        ("1", datetime.now(), models.Participant.BOT.value, "Answer not added?"),
        ("1", datetime.now(), models.Participant.USER.value, "Testtest"),
        # (2, "11:20 11.10.2020", "User", "Testtest"),
        # (3, "11:20 11.10.2020", "Bot", "Testtest"),
        # (4, "11:20 11.10.2020", "User", "Testtest"),
    ]


class TestDatabase:
    def test_can_get_test_obj_with_specific_id(self):
        obj = mixer.blend("database.TestObject", test_id="123456")
        test = models.TestObject.objects.get(test_id=123456)
        assert test.test_id == "123456"

    def test_can_get_de_and_rsm_tests(self):
        lang = mixer.blend("database.LanguagesModel", options="DE")
        t = mixer.blend("database.TopicModel", options="ASSURANCE")

        mixer.blend("database.TestObject", test_id="12345", topic=t, language=lang)
        test = models.TestObject.objects.filter(
            Q(language__options__iexact="DE") & Q(topic__options__iexact="ASSURANCE")
        )
        assert test[0].test_id == "12345"

    def test_can_add_chat_log(id: str):
        # history_item = testobject_factory.testobj_factory(num=1)
        history_item = mixer.blend("database.TestHistoryItem")
        items = make_chat_log()
        df = BaseWebEngine.make_dataframe(items)
        history_item.add_chat_log(df=df)
        chat_log = services.get_most_recent_chat_log(history_item.item_id)
        assert chat_log[0].question == "Success?"

    def test_can_extract_questions_from_chat_log(id: str):
        # history_item = testobject_factory.testobj_factory(num=1)
        history_item = mixer.blend("database.TestHistoryItem")
        items = make_chat_log()
        df = BaseWebEngine.make_dataframe(items)
        history_item.add_chat_log(df=df)
        questions = history_item.get_questions()
        assert questions[0] == "Question added?"
        assert questions[1] == "Testtest"

    def test_can_get_de_or_en_and_not_rsm_tests(self):
        de, _ = models.LanguagesModel.objects.get_or_create(options="DE")
        en, _ = models.LanguagesModel.objects.get_or_create(options="EN")
        rsm, _ = models.TopicModel.objects.get_or_create(options="RSM")
        mixer.blend("database.TestObject", language=de, topic=rsm)
        mixer.blend("database.TestObject", language=en, topic=rsm)
        tests = models.TestObject.objects.filter(
            Q(language__options__startswith="DE")
            | Q(language__options__startswith="EN")
            | ~Q(topic__options__startswith="RSM")
        )
        assert tests

    def test_can_get_non_fr_tests(self):
        fr, _ = models.LanguagesModel.objects.get_or_create(options="FR")
        en, _ = models.LanguagesModel.objects.get_or_create(options="EN")
        rsm, _ = models.TopicModel.objects.get_or_create(options="RSM")
        mixer.blend("database.TestObject", language=fr, topic=rsm)
        tests = models.TestObject.objects.exclude(language__options__startswith="FR")
        assert not tests
        tests = models.TestObject.objects.exclude(language__options__startswith="FR")
        mixer.blend("database.TestObject", language=en, topic=rsm)
        assert tests

    # def test_can_get_language_and_quality_of_all_tests(self):
    #     # values_list returns a list and values returns a dict
    #     tests = (
    #         models.TestObject.objects.all()
    #         .values_list("language")
    #         .union(models.TestHistory.objects.all().values_list("quality"))
    #     )


class TestTimezoneShenanigans:
    time_test_now = timezone.now() - timedelta(days=3)

    @mock.patch("django.utils.timezone.now")
    def test_can_get_tests_older_than_2_days(self, mock_now):
        # https://docs.djangoproject.com/en/4.0/ref/models/querysets/
        # gt == greater than
        # gte == greater than or equal
        # lt == less than
        mock_now.return_value = self.time_test_now
        now = datetime.now()
        two_days_ago = timedelta(days=2)
        mixer.blend("database.TestObject")

        new_tests = models.TestObject.objects.filter(
            created_timestamp__gt=now - two_days_ago
        )
        old_tests = models.TestObject.objects.filter(
            created_timestamp__lt=now - two_days_ago
        )
        assert len(old_tests) == 1
        assert not new_tests
