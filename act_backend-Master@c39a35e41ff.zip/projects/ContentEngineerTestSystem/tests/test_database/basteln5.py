import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from database import models


def most_recent_item():
    id = "bdd7f6d9-15ec-4e36-8246-647cd134000c"
    test = models.TestObject.objects.filter(test_id=id)
    item = test[0].get_most_recent_history_item()
    print(item)


if __name__ == "__main__":
    most_recent_item()
