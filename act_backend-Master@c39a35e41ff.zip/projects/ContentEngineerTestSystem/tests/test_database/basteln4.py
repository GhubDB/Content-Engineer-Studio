import os
from datetime import datetime, timedelta

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()
from database import models, services
from mixer.backend.django import mixer


def t():
    n = datetime.now()
    b = timedelta(days=3)
    return n - b


if __name__ == "__main__":
    item_id = "ee8eb6ea-1164-4784-9a5a-1fd36f412ae5"
    messages = services.get_most_recent_chat_log(test_id=item_id)
    print(messages)
