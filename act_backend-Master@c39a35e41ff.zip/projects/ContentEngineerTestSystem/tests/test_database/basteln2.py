import csv
import os

import django
import pandas as pd

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from database.models import Faq, Languages, Topic, Variant, WlineWless


def test_reader():
    data_file_path = os.path.join(os.path.dirname(__file__), "FAQs.xlsx")
    dataset = pd.read_excel(data_file_path)
    lang, created = Languages.objects.get_or_create(language="DE")
    for row in dataset.to_dict(orient="records"):
        t, created = Topic.objects.get_or_create(topic=row["Cluster"])
        line, created = WlineWless.objects.get_or_create(
            wline_wless=row["Wireless / Wireline"]
        )
        faq = Faq(
            faq_id=row["ID"],
            faq_name=row["Name"],
            topic=t,
            wline_wless=line,
            question=row["Question"],
            answer=row["Answer"],
            text_link=row["Text Link"],
            link=row["Link"],
            comment=row["Bemerkungen"],
            language=lang,
        )
        faq.save()
    print(dataset)


if __name__ == "__main__":
    test_reader()
