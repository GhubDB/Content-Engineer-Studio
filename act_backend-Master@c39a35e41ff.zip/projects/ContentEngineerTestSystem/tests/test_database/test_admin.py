import pytest
from django.contrib.admin.sites import AdminSite
from mixer.backend.django import mixer

pytestmark = pytest.mark.django_db

from database.admin import PostAdmin
from database.models import Post


class TestPostAdmin:
    def test_excerpt(self):
        site = AdminSite()
        post_admin = PostAdmin(Post, site)

        obj = mixer.blend("database.Post", body="Hello World")
        result = post_admin.excerpt(obj)
        assert result == "Hello", "Should return first few characters"
