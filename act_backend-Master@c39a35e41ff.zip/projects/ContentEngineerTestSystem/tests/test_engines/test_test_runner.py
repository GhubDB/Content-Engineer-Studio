import pandas as pd
import pytest


@pytest.mark.usefixtures("make_test_runner")
class BasicTest:
    pass


class Test_TestRunner(BasicTest):
    def test_can_run_whatsapp_test(self, request):
        assert self.test_runner.test_obj.chat_logs == {}
        test_obj = self.test_runner.run_test()
