import os
import re
import time
from datetime import datetime

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

import pandas as pd
from database.models import TestModes
from test_runner.cets_selenium.selenium_helpers import Browser
from test_runner.engines.whatsapp_engine import WhatsAppEngine


class Test_WhatsAppContextManager:
    def test_can_send_and_receive_messages(self):
        engine = WhatsAppEngine()
        with engine.manager():
            assert engine.is_ready()
            time.sleep(3)
            assert engine.send_message(text="test text")
            last_message = engine.get_last_messages(number=1)
            assert last_message[0] == "test text"
            engine.await_response(last_sent_message="test text", timeout_in_seconds=60)
            chat_log = engine.get_chat_log()
            assert isinstance(chat_log, pd.DataFrame)
            assert chat_log.shape[0] > 1, "Chat log should have messages in it"

    def test_can_split_tags_and_clean_data(self):
        engine = WhatsAppEngine()
        tags = engine.split_time_date_name(message="[06:20, 11.6.2022] BOT_PROD:")
        output = """[datetime.datetime(2022, 6, 11, 6, 20, tzinfo=zoneinfo.ZoneInfo(key='UTC')), 'BOT']"""
        assert str(tags) == output
        tags = engine.split_time_date_name(message="[06:20, 11.6.2022] 0796487997:")
        output = """[datetime.datetime(2022, 6, 11, 6, 20, tzinfo=zoneinfo.ZoneInfo(key='UTC')), 'USER']"""
        assert str(tags) == output
