import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

import traceback

from database.models import TestModes
from selenium import webdriver
from selenium.webdriver.common.by import By
from test_runner.cets_selenium.selenium_helpers import Browser
from test_runner.data.constants import Keys, Urls


def testing():
    try:
        browser = Browser()
        browser.options.add_experimental_option(
            "excludeSwitches", ["enable-automation"]
        )
        browser.options.add_experimental_option("useAutomationExtension", False)
        browser.set_up(host="http://localhost:4445/wd/hub")
        browser.get_url(Urls.WEB[TestModes.WHATSAPP])
        # text = "test"
        # target = "[title*='Schreib eine Nachricht']"

        # element = browser.get_element(
        #     target=target, seconds=60, selector=By.CSS_SELECTOR
        # )
        # element = browser.driver.find_element(
        #     By.CSS_SELECTOR, "[title*='Type a message']"
        # )
        # element.click()
        # browser.send_input(target=target, text=text, selector=By.CSS_SELECTOR)
        # browser.send_input(target=target, text=Keys.ENTER, selector=By.CSS_SELECTOR)

    except:
        traceback.print_exc()

    finally:
        input("press enter to quit")
        browser.tear_down()
        # browser.quit()


if __name__ == "__main__":
    testing()
