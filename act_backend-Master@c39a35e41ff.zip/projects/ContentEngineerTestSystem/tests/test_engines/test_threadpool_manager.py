import queue

import pytest
from test_runner.results import TestObj


@pytest.mark.usefixtures("make_manager")
class BasicTest:
    pass


class Test_ThreadPoolManager(BasicTest):
    def test_can_run_whatsapp_tests(self):
        pass
