import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

# import pytest
# from test_runner.engines.whatsapp_engine import WhatsAppEngine
# from test_runner.threadpool_manager import ThreadPoolManager

# from tests.testobject_factory import testobj_factory

# https://www.lambdatest.com/blog/end-to-end-tutorial-for-pytest-fixtures-with-examples/
# This fixture sets up and shuts down the browser for each test class
# @pytest.fixture(scope="class")
# def driver(request):
#     engine = WhatsAppEngine()
#     engine.start_engine()

#     # request.cls is the test class that is using the function
#     request.cls.engine = engine
#     request.cls.browser = engine.browser

#     # Test happens here
#     yield

#     # Cleanup
#     engine.stop_engine()


# @pytest.fixture(scope="class")
# def make_manager(request):
#     thread_manager = ThreadPoolManager()
#     request.cls.thread_manager = thread_manager
#     request.cls.questions = testobj_factory(3)

#     yield

#     thread_manager.stop()


# @pytest.fixture(scope="class")
# def make_test_runner(request):
#     test_objects = testobj_factory(1)
#     test_runner = TestRunner(test_obj=test_objects[0])
#     request.cls.test_runner = test_runner

#     yield
