import json
import logging

import pytest
from database import models
from django.urls import reverse
from mixer.backend.django import mixer
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.test import APITestCase
from tests.testobject_factory import testobj_factory

pytestmark = pytest.mark.django_db


class TestPostDetails(APITestCase):
    def test_add_history_item_view_is_reachable_by_anyone(self):
        # 'api' is the route and 'new_history_item' is the name of the route -> urls.py
        url = reverse("api:new_history_item")
        # 'client' simulates a browser
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_can_create_test_object(self):
        data = {"story_id": "123456"}
        url = reverse("api:new_test")
        response = self.client.post(url, data, format="json")
        self.assertEqual(
            response.status_code, status.HTTP_201_CREATED
        ), "Can create a new TestObject"

    def test_can_update_test_object_story_id(self):
        obj = mixer.blend(models.TestObject, story_id="123456", pk="1")
        self.assertEqual(obj.story_id, "123456")
        self.assertEqual(obj.pk, 1)
        data = {"story_id": "23548"}
        url = reverse(f"api:get_test", args=[obj.test_id])
        response = self.client.put(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK),
        testobj = models.TestObject.objects.filter(pk=1)
        self.assertEqual(testobj[0].story_id, "23548")

    def test_can_update_test_object_topic(self):
        topic = models.TopicModel.objects.create(options="Assurance")
        topic2 = models.TopicModel.objects.create(options="Fulfillment")
        obj = mixer.blend(models.TestObject, topic=topic, pk="1")
        self.assertEqual(obj.topic, topic)
        # data = {"topic": 2}
        data = {"topic": {"id": 2}}
        url = reverse(f"api:get_test", args=[obj.test_id])
        response = self.client.put(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK),
        testobj = models.TestObject.objects.filter(pk=1)
        self.assertEqual(testobj[0].topic, topic2)
