import os
import random

import django

# from operator import is_


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from database.models import (
    CustomUser,
    Questions,
    TestHistoryItem,
    TestModes,
    TestModesModel,
    TestObject,
    Variant,
)
from mixer.backend.django import mixer


def get_random_entry(cls, number: int = 1):
    pks = cls.objects.values_list("pk", flat=True)
    output = []
    if number == 1:
        pk = random.choice(pks)
        return cls.objects.get(pk=pk)
    for item in range(number):
        pk = random.choice(pks)
        output.append(cls.objects.get(pk=pk))
    return output


def testobj_factory(
    num: int = 10, is_live: bool = False, questions: bool = True
) -> list[TestHistoryItem]:
    """
    This class makes database entries for Testobjects, TestHistoryItems and Questions
    assigns random values for test purposes
    """
    tests = []
    for test_object in range(num):

        variant = get_random_entry(cls=Variant)
        story_id = random.randint(10000, 50000)
        userid, _ = CustomUser.objects.get_or_create(username="Tester")

        test_object = mixer.blend(
            TestObject,
            created_userid=userid,
            story_id=story_id,
            wline_wless=variant.faq.wline_wless,
            language=variant.faq.language,
            topic=variant.faq.topic,
        )

        mode = TestModesModel.objects.get(options="WHATSAPP")
        test_history_item = TestHistoryItem(test=test_object, is_live=is_live)
        test_history_item.save()
        test_history_item.modes.add(mode)
        test_history_item.save()

        if questions:
            questions = mixer.blend(
                Questions,
                history_item=test_history_item,
                question=variant.question,
                number=1,
            )
            questions.save()
            # print(test_history_item.modes.all())
        tests.append(test_history_item)

    return tests


if __name__ == "__main__":
    # User.objects.create(name="Tester")
    # print(testobj_factory(num=1, is_live=True, questions=False))
    print(testobj_factory(num=1))
